<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>$ClassName$</name>
    <message>
        <source>$ClassName$</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ChartItemEditor</name>
    <message>
        <source>Series</source>
        <translation></translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Agregar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Values field</source>
        <translation>Valores del campo</translation>
    </message>
    <message>
        <source>Color</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Labels field</source>
        <translation>Etiquetas del campo</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Series editor</source>
        <translation>Editor de Series</translation>
    </message>
    <message>
        <source>Series name</source>
        <translation>Nombre de la Serie</translation>
    </message>
</context>
<context>
    <name>ImageItemEditor</name>
    <message>
        <source>Image Item Editor</source>
        <translation>Editor de imagen de objeto</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Resource path</source>
        <translation>Ruta de recurso</translation>
    </message>
    <message>
        <source>Select image file</source>
        <translation>Selecione un archivo de imagen</translation>
    </message>
</context>
<context>
    <name>LRVariableDialog</name>
    <message>
        <source>Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Atención</translation>
    </message>
    <message>
        <source>Mandatory</source>
        <translation>Obligatorio</translation>
    </message>
</context>
<context>
    <name>LanguageSelectDialog</name>
    <message>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
</context>
<context>
    <name>LimeReport::AboutDialog</name>
    <message>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Lime Report</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Arin Alexander&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;arin_a@bk.ru&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Version 1.1.1</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;img src=&quot;:/report/images/logo_100.png&quot; height=&quot;100&quot; style=&quot;float: left;&quot; /&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Report engine for &lt;/span&gt;&lt;span style=&quot; font-size:12pt; font-weight:600; color:#7faa18;&quot;&gt;Qt&lt;/span&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt; framework&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;LimeReport - multi-platform C++ library written using Qt framework and intended for software developers that would like to add into their application capability to form report or print forms generated using templates.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;Official web site : &lt;/span&gt;&lt;a href=&quot;www.limereport.ru&quot;&gt;&lt;span style=&quot; font-size:11pt; text-decoration: underline; color:#0000ff;&quot;&gt;www.limereport.ru&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt; text-decoration: underline; color:#0000ff;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-weight:600; color:#000000;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Copyright 2015 Arin Alexander. All rights reserved.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;img src=&quot;:/report/images/logo_100.png&quot; height=&quot;100&quot; style=&quot;float: left;&quot; /&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Motor de informes para el entorno de trabajo de &lt;/span&gt; &lt;span style = &quot;font-size: 12pt; font-weight: 600; color: # 7faa18;&quot;&gt; Qt &lt;/span&gt; &lt;span style = &quot;font-size: 12pt; font-weight : 600; &quot;&gt;&lt;/span&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot; &gt; &lt;span style = &quot;font-size: 11pt;&quot;&gt; LimeReport es una biblioteca de C ++ multiplataforma escrita para el entorno de trabajo de Qt y diseñada para desarrolladores de software que deseen agregar en su aplicación la capacidad para crear informes o imprimir formularios generados mediante plantillas. &lt; / span&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px; font-size: 11pt; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px; font-size: 11pt; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot; &gt; &lt;span style = &quot;font-size: 11pt;&quot;&gt; Sitio web oficial: &lt;/span&gt; &lt;a href=&quot;www.limereport.ru&quot;&gt; &lt;span style = &quot;font-size: 11pt; text-decoration: underline ; color: # 0000ff; &quot;&gt; www.limereport.ru &lt;/span&gt; &lt;/a&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; texto-sangría: 0px; fuente-tamaño: 11 puntos; texto-decoración: subrayado; color: # 0000ff; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot; &gt; &lt;span style = &quot;font-size: 10pt; font-weight: 600;&quot;&gt; Esta biblioteca se distribuye con la esperanza de que sea útil, pero SIN NINGUNA GARANTÍA; sin ni siquiera la garantía implícita de COMERCIABILIDAD o APTITUD PARA UN PROPÓSITO PARTICULAR. &lt;/span&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px; font-size: 10pt; font-weight: 600; color: # 000000; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p align = &quot;justify&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot; &gt; &lt;span style = &quot;font-size: 10pt;&quot;&gt;Derechos reservados 2015 Arin Alexander. Todos los derechos reservados.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;(c) 2015 Arin Alexander arin_a@bk.ru&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;G&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;NU LESSER GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Version 2.1, February 1999&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Copyright (C) 1991, 1999 Free Software Foundation, Inc.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;of this license document, but changing it is not allowed.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;[This is the first released version of the Lesser GPL.  It also counts&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt; as the successor of the GNU Library Public License, version 2, hence&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt; the version number 2.1.]&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;reamble&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;The licenses for most software are designed to take away your freedom to share and change it. By contrast, the GNU General Public Licenses are intended to guarantee your freedom to share and change free software--to make sure the software is free for all its users.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;This license, the Lesser General Public License, applies to some specially designated software packages--typically libraries--of the Free Software Foundation and other authors who decide to use it. You can use it too, but we suggest you first think carefully about whether this license or the ordinary General Public License is the better strategy to use in any particular case, based on the explanations below.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;When we speak of free software, we are referring to freedom of use, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for this service if you wish); that you receive source code or can get it if you want it; that you can change the software and use pieces of it in new free programs; and that you are informed that you can do these things.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;To protect your rights, we need to make restrictions that forbid distributors to deny you these rights or to ask you to surrender these rights. These restrictions translate to certain responsibilities for you if you distribute copies of the library or if you modify it.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;For example, if you distribute copies of the library, whether gratis or for a fee, you must give the recipients all the rights that we gave you. You must make sure that they, too, receive or can get the source code. If you link other code with the library, you must provide complete object files to the recipients, so that they can relink them with the library after making changes to the library and recompiling it. And you must show them these terms so they know their rights.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;We protect your rights with a two-step method: (1) we copyright the library, and (2) we offer you this license, which gives you legal permission to copy, distribute and/or modify the library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;To protect each distributor, we want to make it very clear that there is no warranty for the free library. Also, if the library is modified by someone else and passed on, the recipients should know that what they have is not the original version, so that the original author&apos;s reputation will not be affected by problems that might be introduced by others.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Finally, software patents pose a constant threat to the existence of any free program. We wish to make sure that a company cannot effectively restrict the users of a free program by obtaining a restrictive license from a patent holder. Therefore, we insist that any patent license obtained for a version of the library must be consistent with the full freedom of use specified in this license.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Most GNU software, including some libraries, is covered by the ordinary GNU General Public License. This license, the GNU Lesser General Public License, applies to certain designated libraries, and is quite different from the ordinary General Public License. We use this license for certain libraries in order to permit linking those libraries into non-free programs.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;When a program is linked with a library, whether statically or using a shared library, the combination of the two is legally speaking a combined work, a derivative of the original library. The ordinary General Public License therefore permits such linking only if the entire combination fits its criteria of freedom. The Lesser General Public License permits more lax criteria for linking other code with the library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;We call this license the &amp;quot;Lesser&amp;quot; General Public License because it does Less to protect the user&apos;s freedom than the ordinary General Public License. It also provides other free software developers Less of an advantage over competing non-free programs. These disadvantages are the reason we use the ordinary General Public License for many libraries. However, the Lesser license provides advantages in certain special circumstances.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;For example, on rare occasions, there may be a special need to encourage the widest possible use of a certain library, so that it becomes a de-facto standard. To achieve this, non-free programs must be allowed to use the library. A more frequent case is that a free library does the same job as widely used non-free libraries. In this case, there is little to gain by limiting the free library to free software only, so we use the Lesser General Public License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;In other cases, permission to use a particular library in non-free programs enables a greater number of people to use a large body of free software. For example, permission to use the GNU C Library in non-free programs enables many more people to use the whole GNU operating system, as well as its variant, the GNU/Linux operating system.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Although the Lesser General Public License is Less protective of the users&apos; freedom, it does ensure that the user of a program that is linked with the Library has the freedom and the wherewithal to run that program using a modified version of the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. Pay close attention to the difference between a &amp;quot;work based on the library&amp;quot; and a &amp;quot;work that uses the library&amp;quot;. The former contains code derived from the library, whereas the latter must be combined with the library in order to run.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;ERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;0.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; This License Agreement applies to any software library or other program which contains a notice placed by the copyright holder or other authorized party saying it may be distributed under the terms of this Lesser General Public License (also called &amp;quot;this License&amp;quot;). Each licensee is addressed as &amp;quot;you&amp;quot;.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;A &amp;quot;library&amp;quot; means a collection of software functions and/or data prepared so as to be conveniently linked with application programs (which use some of those functions and data) to form executables.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;The &amp;quot;Library&amp;quot;, below, refers to any such software library or work which has been distributed under these terms. A &amp;quot;work based on the Library&amp;quot; means either the Library or any derivative work under copyright law: that is to say, a work containing the Library or a portion of it, either verbatim or with modifications and/or translated straightforwardly into another language. (Hereinafter, translation is included without limitation in the term &amp;quot;modification&amp;quot;.)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;&amp;quot;Source code&amp;quot; for a work means the preferred form of the work for making modifications to it. For a library, complete source code means all the source code for all modules it contains, plus any associated interface definition files, plus the scripts used to control compilation and installation of the library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Activities other than copying, distribution and modification are not covered by this License; they are outside its scope. The act of running a program using the Library is not restricted, and output from such a program is covered only if its contents constitute a work based on the Library (independent of the use of the Library in a tool for writing it). Whether that is true depends on what the Library does and what the program that uses the Library does.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;1.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may copy and distribute verbatim copies of the Library&apos;s complete source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice and disclaimer of warranty; keep intact all the notices that refer to this License and to the absence of any warranty; and distribute a copy of this License along with the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;You may charge a fee for the physical act of transferring a copy, and you may at your option offer warranty protection in exchange for a fee.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;2.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may modify your copy or copies of the Library or any portion of it, thus forming a work based on the Library, and copy and distribute such modifications or work under the terms of Section 1 above, provided that you also meet all of these conditions:&lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:19px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;a)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; The modified work must itself be a software library.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;b)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; You must cause the files modified to carry prominent notices stating that you changed the files and the date of any change.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;c)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; You must cause the whole of the work to be licensed at no charge to all third parties under the terms of this License.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:19px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;d)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; If a facility in the modified Library refers to a function or a table of data to be supplied by an application program that uses the facility, other than as an argument passed when the facility is invoked, then you must make a good faith effort to ensure that, in the event an application does not supply such function or table, the facility still operates, and performs whatever part of its purpose remains meaningful.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:38px; margin-right:19px; -qt-block-indent:1; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;(For example, a function in a library to compute square roots has a purpose that is entirely well-defined independent of the application. Therefore, Subsection 2d requires that any application-supplied function or table used by this function must be optional: if the application does not supply it, the square root function must still compute square roots.)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;These requirements apply to the modified work as a whole. If identifiable sections of that work are not derived from the Library, and can be reasonably considered independent and separate works in themselves, then this License, and its terms, do not apply to those sections when you distribute them as separate works. But when you distribute the same sections as part of a whole which is a work based on the Library, the distribution of the whole must be on the terms of this License, whose permissions for other licensees extend to the entire whole, and thus to each and every part regardless of who wrote it.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Thus, it is not the intent of this section to claim rights or contest your rights to work written entirely by you; rather, the intent is to exercise the right to control the distribution of derivative or collective works based on the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;In addition, mere aggregation of another work not based on the Library with the Library (or with a work based on the Library) on a volume of a storage or distribution medium does not bring the other work under the scope of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;3.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may opt to apply the terms of the ordinary GNU General Public License instead of this License to a given copy of the Library. To do this, you must alter all the notices that refer to this License, so that they refer to the ordinary GNU General Public License, version 2, instead of to this License. (If a newer version than version 2 of the ordinary GNU General Public License has appeared, then you can specify that version instead if you wish.) Do not make any other change in these notices.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Once this change is made in a given copy, it is irreversible for that copy, so the ordinary GNU General Public License applies to all subsequent copies and derivative works made from that copy.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;This option is useful when you wish to copy part of the code of the Library into a program that is not a library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;4.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may copy and distribute the Library (or a portion or derivative of it, under Section 2) in object code or executable form under the terms of Sections 1 and 2 above provided that you accompany it with the complete corresponding machine-readable source code, which must be distributed under the terms of Sections 1 and 2 above on a medium customarily used for software interchange.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If distribution of object code is made by offering access to copy from a designated place, then offering equivalent access to copy the source code from the same place satisfies the requirement to distribute the source code, even though third parties are not compelled to copy the source along with the object code.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;5.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; A program that contains no derivative of any portion of the Library, but is designed to work with the Library by being compiled or linked with it, is called a &amp;quot;work that uses the Library&amp;quot;. Such a work, in isolation, is not a derivative work of the Library, and therefore falls outside the scope of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;However, linking a &amp;quot;work that uses the Library&amp;quot; with the Library creates an executable that is a derivative of the Library (because it contains portions of the Library), rather than a &amp;quot;work that uses the library&amp;quot;. The executable is therefore covered by this License. Section 6 states terms for distribution of such executables.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;When a &amp;quot;work that uses the Library&amp;quot; uses material from a header file that is part of the Library, the object code for the work may be a derivative work of the Library even though the source code is not. Whether this is true is especially significant if the work can be linked without the Library, or if the work is itself a library. The threshold for this to be true is not precisely defined by law.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If such an object file uses only numerical parameters, data structure layouts and accessors, and small macros and small inline functions (ten lines or less in length), then the use of the object file is unrestricted, regardless of whether it is legally a derivative work. (Executables containing this object code plus portions of the Library will still fall under Section 6.)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Otherwise, if the work is a derivative of the Library, you may distribute the object code for the work under the terms of Section 6. Any executables containing that work also fall under Section 6, whether or not they are linked directly with the Library itself.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;6.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; As an exception to the Sections above, you may also combine or link a &amp;quot;work that uses the Library&amp;quot; with the Library to produce a work containing portions of the Library, and distribute that work under terms of your choice, provided that the terms permit modification of the work for the customer&apos;s own use and reverse engineering for debugging such modifications.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;You must give prominent notice with each copy of the work that the Library is used in it and that the Library and its use are covered by this License. You must supply a copy of this License. If the work during execution displays copyright notices, you must include the copyright notice for the Library among them, as well as a reference directing the user to the copy of this License. Also, you must do one of these things:&lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:19px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;a)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Accompany the work with the complete corresponding machine-readable source code for the Library including whatever changes were used in the work (which must be distributed under Sections 1 and 2 above); and, if the work is an executable linked with the Library, with the complete machine-readable &amp;quot;work that uses the Library&amp;quot;, as object code and/or source code, so that the user can modify the Library and then relink to produce a modified executable containing the modified Library. (It is understood that the user who changes the contents of definitions files in the Library will not necessarily be able to recompile the application to use the modified definitions.)&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;b)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Use a suitable shared library mechanism for linking with the Library. A suitable mechanism is one that (1) uses at run time a copy of the library already present on the user&apos;s computer system, rather than copying library functions into the executable, and (2) will operate properly with a modified version of the library, if the user installs one, as long as the modified version is interface-compatible with the version that the work was made with.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;c)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Accompany the work with a written offer, valid for at least three years, to give the same user the materials specified in Subsection 6a, above, for a charge no more than the cost of performing this distribution.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;d)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; If distribution of the work is made by offering access to copy from a designated place, offer equivalent access to copy the above specified materials from the same place.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:19px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;e)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Verify that the user has already received a copy of these materials or that you have already sent this user a copy.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;For an executable, the required form of the &amp;quot;work that uses the Library&amp;quot; must include any data and utility programs needed for reproducing the executable from it. However, as a special exception, the materials to be distributed need not include anything that is normally distributed (in either source or binary form) with the major components (compiler, kernel, and so on) of the operating system on which the executable runs, unless that component itself accompanies the executable.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;It may happen that this requirement contradicts the license restrictions of other proprietary libraries that do not normally accompany the operating system. Such a contradiction means you cannot use both them and the Library together in an executable that you distribute.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;7.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may place library facilities that are a work based on the Library side-by-side in a single library together with other library facilities not covered by this License, and distribute such a combined library, provided that the separate distribution of the work based on the Library and of the other library facilities is otherwise permitted, and provided that you do these two things:&lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:19px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;a)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Accompany the combined library with a copy of the same work based on the Library, uncombined with any other library facilities. This must be distributed under the terms of the Sections above.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:19px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;b)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Give prominent notice with the combined library of the fact that part of it is a work based on the Library, and explaining where to find the accompanying uncombined form of the same work.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;8.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may not copy, modify, sublicense, link with, or distribute the Library except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, link with, or distribute the Library is void, and will automatically terminate your rights under this License. However, parties who have received copies, or rights, from you under this License will not have their licenses terminated so long as such parties remain in full compliance.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;9.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You are not required to accept this License, since you have not signed it. However, nothing else grants you permission to modify or distribute the Library or its derivative works. These actions are prohibited by law if you do not accept this License. Therefore, by modifying or distributing the Library (or any work based on the Library), you indicate your acceptance of this License to do so, and all its terms and conditions for copying, distributing or modifying the Library or works based on it.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;10.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; Each time you redistribute the Library (or any work based on the Library), the recipient automatically receives a license from the original licensor to copy, distribute, link with or modify the Library subject to these terms and conditions. You may not impose any further restrictions on the recipients&apos; exercise of the rights granted herein. You are not responsible for enforcing compliance by third parties with this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;11.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; If, as a consequence of a court judgment or allegation of patent infringement or for any other reason (not limited to patent issues), conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot distribute so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not distribute the Library at all. For example, if a patent license would not permit royalty-free redistribution of the Library by all those who receive copies directly or indirectly through you, then the only way you could satisfy both it and this License would be to refrain entirely from distribution of the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If any portion of this section is held invalid or unenforceable under any particular circumstance, the balance of the section is intended to apply, and the section as a whole is intended to apply in other circumstances.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;It is not the purpose of this section to induce you to infringe any patents or other property right claims or to contest validity of any such claims; this section has the sole purpose of protecting the integrity of the free software distribution system which is implemented by public license practices. Many people have made generous contributions to the wide range of software distributed through that system in reliance on consistent application of that system; it is up to the author/donor to decide if he or she is willing to distribute software through any other system and a licensee cannot impose that choice.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;This section is intended to make thoroughly clear what is believed to be a consequence of the rest of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;12.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; If the distribution and/or use of the Library is restricted in certain countries either by patents or by copyrighted interfaces, the original copyright holder who places the Library under this License may add an explicit geographical distribution limitation excluding those countries, so that distribution is permitted only in or among countries not thus excluded. In such case, this License incorporates the limitation as if written in the body of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;13.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; The Free Software Foundation may publish revised and/or new versions of the Lesser General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Each version is given a distinguishing version number. If the Library specifies a version number of this License which applies to it and &amp;quot;any later version&amp;quot;, you have the option of following the terms and conditions either of that version or of any later version published by the Free Software Foundation. If the Library does not specify a license version number, you may choose any version ever published by the Free Software Foundation.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;14.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; If you wish to incorporate parts of the Library into other free programs whose distribution conditions are incompatible with these, write to the author to ask for permission. For software which is copyrighted by the Free Software Foundation, write to the Free Software Foundation; we sometimes make exceptions for this. Our decision will be guided by the two goals of preserving the free status of all derivatives of our free software and of promoting the sharing and reuse of software generally.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;NO WARRANTY&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;15.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; BECAUSE THE LIBRARY IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE LIBRARY, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE LIBRARY &amp;quot;AS IS&amp;quot; WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE LIBRARY IS WITH YOU. SHOULD THE LIBRARY PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;16.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE LIBRARY AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE LIBRARY (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE LIBRARY TO OPERATE WITH ANY OTHER SOFTWARE), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;END OF TERMS AND CONDITIONS&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;ow to Apply These Terms to Your New Libraries&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If you develop a new library, and you want it to be of the greatest possible use to the public, we recommend making it free software that everyone can redistribute and change. You can do so by permitting redistribution under these terms (or, alternatively, under the terms of the ordinary General Public License).&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;To apply these terms, attach the following notices to the library. It is safest to attach them to the start of each source file to most effectively convey the exclusion of warranty; and each file should have at least the &amp;quot;copyright&amp;quot; line and a pointer to where the full notice is found.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;one line to give the library&apos;s name and an idea of what it does.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Copyright (C) &lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;year&lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;  &lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;name of author&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;This library is free software; you can redistribute it and/or&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;modify it under the terms of the GNU Lesser General Public&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;License as published by the Free Software Foundation; either&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;version 2.1 of the License, or (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;This library is distributed in the hope that it will be useful,&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Lesser General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;You should have received a copy of the GNU Lesser General Public&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;License along with this library; if not, write to the Free Software&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Also add information on how to contact you by electronic and paper mail.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;You should also get your employer (if you work as a programmer) or your school, if any, to sign a &amp;quot;copyright disclaimer&amp;quot; for the library, if necessary. Here is a sample; alter the names:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Yoyodyne, Inc., hereby disclaims all copyright interest in&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;the library `Frob&apos; (a library for tweaking knobs) written&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;by James Random Hacker.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;signature of Ty Coon&lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;, 1 April 1990&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Ty Coon, President of Vice&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;That&apos;s all there is to it!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;(c) 2015 Arin Alexander arin_a@bk.ru&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;G&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;LICENCIA PUBLICA GENERAL DE MENORES DE NU&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Versión 2.1, febrero de 1999&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Copyright (C) 1991, 1999 Free Software Foundation, Inc.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Todos están autorizados a copiar y distribuir copias textuales.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;de este documento de licencia, pero no está permitido cambiarlo.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;[Esta es la primera versión lanzada de Lesser GPL. Tambien cuenta&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt; como el sucesor de la Licencia Pública de la Biblioteca GNU, versión 2, de ahí&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt; el número de versión 2.1.]&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;reamble&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Las licencias para la mayoría de los programas están diseñadas para quitarle la libertad de compartir y cambiar. Por el contrario, las licencias públicas generales de GNU están destinadas a garantizar su libertad de compartir y cambiar el software libre, para garantizar que el software sea gratuito para todos sus usuarios. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Esta licencia, la Licencia de Público General Menor, se aplica a algunos paquetes de software especialmente designados, generalmente bibliotecas, de la Free Software Foundation y otros autores que deciden usarla. También puede usarlo, pero le sugerimos que primero piense detenidamente si esta licencia o la Licencia pública general es la mejor estrategia para usar en un caso particular, según las explicaciones a continuación. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Cuando hablamos de software libre, nos referimos a la libertad de uso, no al precio. Nuestras licencias públicas generales están diseñadas para garantizar que usted tenga la libertad de distribuir copias de software gratuito (y puede cobrar por este servicio si lo desea); que recibe el código fuente o puede obtenerlo si lo desea; que puede cambiar el software y usar partes de él en nuevos programas gratuitos; y que está informado de que puede hacer estas cosas. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Para proteger sus derechos, necesitamos hacer restricciones que prohíban a los distribuidores negarle estos derechos o pedirle que renuncie a estos derechos. Estas restricciones se traducen en ciertas responsabilidades para usted si distribuye copias de la biblioteca o si la modifica.&lt;/span&gt;&lt;/p&gt;

&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Por ejemplo, si distribuye copias de la biblioteca, ya sea de forma gratuita o por una tarifa, debe otorgar a los destinatarios todos los derechos que le otorgamos. Debe asegurarse de que ellos también reciban o puedan obtener el código fuente. Si vincula otro código con la biblioteca, debe proporcionar archivos de objetos completos a los destinatarios, para que puedan volver a vincularlos con la biblioteca después de realizar cambios en la biblioteca y volver a compilarla. Y debe mostrarles estos términos para que conozcan sus derechos. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Protegemos sus derechos con un método de dos pasos: (1) protegemos los derechos de autor de la biblioteca y (2) le ofrecemos esta licencia, que le da permiso legal para copiar, distribuir y / o modificar la biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Para proteger a cada distribuidor, queremos dejar muy claro que no hay garantía para la biblioteca gratuita. Además, si la biblioteca es modificada por alguien más y se transmite, los destinatarios deben saber que lo que tienen no es la versión original, por lo que la reputación del autor original no se verá afectada por problemas que puedan ser introducidos por otros. &lt;/ Span &gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Finalmente, las patentes de software representan una amenaza constante para la existencia de cualquier programa gratuito. Deseamos asegurarnos de que una empresa no pueda restringir efectivamente a los usuarios de un programa gratuito al obtener una licencia restrictiva de un titular de una patente. Por lo tanto, insistimos en que cualquier licencia de patente obtenida para una versión de la biblioteca debe ser consistente con la plena libertad de uso especificada en esta licencia. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; La mayoría del software GNU, incluidas algunas bibliotecas, está cubierto por la Licencia Pública General de GNU. Esta licencia, la licencia pública general menor de GNU, se aplica a ciertas bibliotecas designadas y es bastante diferente de la licencia pública general ordinaria. Utilizamos esta licencia para ciertas bibliotecas con el fin de permitir la vinculación de esas bibliotecas con programas no libres.&lt;/span&gt;&lt;/p&gt;

&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Cuando un programa está vinculado con una biblioteca, ya sea estáticamente o utilizando una biblioteca compartida, la combinación de los dos es legalmente una obra combinada, un derivado de la biblioteca original. Por lo tanto, la Licencia Pública General ordinaria permite dicha vinculación solo si la combinación completa cumple con sus criterios de libertad. La licencia pública general de Lesser permite criterios más laxos para vincular otro código con la biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Llamamos a esta licencia el &amp; quot; Lesser &amp; quot; Licencia pública general porque hace menos para proteger la libertad del usuario que la licencia pública general ordinaria. También proporciona a otros desarrolladores de software libre una ventaja menor sobre los programas no gratuitos de la competencia. Estas desventajas son la razón por la que usamos la Licencia Pública General ordinaria para muchas bibliotecas. Sin embargo, la licencia Lesser ofrece ventajas en ciertas circunstancias especiales. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Por ejemplo, en raras ocasiones, puede haber una necesidad especial de fomentar el uso más amplio posible de una determinada biblioteca, para que se convierta en un estándar de facto. Para lograr esto, se debe permitir que los programas no libres utilicen la biblioteca. Un caso más frecuente es que una biblioteca gratuita hace el mismo trabajo que las bibliotecas no libres ampliamente utilizadas. En este caso, hay poco que ganar al limitar la biblioteca gratuita únicamente al software libre, por lo que usamos la Licencia pública general menor. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; En otros casos, el permiso para usar una biblioteca particular en programas no libres permite que una mayor cantidad de personas utilicen una gran cantidad de software libre. Por ejemplo, el permiso para usar la Biblioteca GNU C en programas no libres permite que muchas más personas utilicen todo el sistema operativo GNU, así como su variante, el sistema operativo GNU / Linux.&lt;/span&gt;&lt;/p&gt;

&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Aunque la Licencia pública general menor protege menos la libertad de los usuarios, garantiza que el usuario de un programa vinculado a la Biblioteca tenga la libertad y los medios para ejecutar dicho programa utilizando una versión modificada de la Biblioteca. &lt;/ span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Los términos y condiciones precisos para la copia, distribución y modificación se encuentran a continuación. Preste mucha atención a la diferencia entre un trabajo basado en la biblioteca &amp; quot; y un &amp; quot; trabajo que utiliza la biblioteca &amp; quot ;. El primero contiene código derivado de la biblioteca, mientras que el último debe combinarse con la biblioteca para poder ejecutarse. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 15px; margin-bottom: 15px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;a name = &quot;SEC3&quot;&gt; &lt;/a&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600; color: # 333333;&quot;&gt; T &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600; color: # 333333; &quot;&gt; ERMS Y CONDICIONES PARA LA COPIA, DISTRIBUCIÓN Y MODIFICACIÓN &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 0. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Este Acuerdo de licencia se aplica a cualquier biblioteca de software u otro programa que contenga un aviso colocado por el titular de los derechos de autor u otra parte autorizada que indique que se puede distribuir de acuerdo con los términos de esta Licencia pública general menor (también denominada &quot;esta Licencia&quot;). Cada licenciatario se direcciona como &amp; quot; usted &amp; quot ;. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; A &amp; quot; library &amp; quot; significa una colección de funciones de software y / o datos preparados para estar convenientemente vinculados con programas de aplicación (que utilizan algunas de esas funciones y datos) para formar ejecutables. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; La &amp; quot; Biblioteca &amp; quot ;, a continuación, se refiere a cualquier biblioteca de software o trabajo que se haya distribuido bajo estos términos. Un &quot;trabajo basado en la Biblioteca&quot; significa la Biblioteca o cualquier trabajo derivado bajo la ley de derechos de autor: es decir, un trabajo que contiene la Biblioteca o una parte de ella, ya sea textualmente o con modificaciones y / o traducido directamente a otro idioma. (De aquí en adelante, la traducción se incluye sin limitación en el término &quot;modificación&quot;).&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;&amp; quot; Código fuente &amp; quot; para un trabajo significa la forma preferida del trabajo para hacer modificaciones al mismo. Para una biblioteca, el código fuente completo significa todo el código fuente de todos los módulos que contiene, más cualquier archivo de definición de interfaz asociado, además de los scripts utilizados para controlar la compilación e instalación de la biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Las actividades que no sean la copia, distribución y modificación no están cubiertas por esta Licencia; Están fuera de su alcance. El acto de ejecutar un programa utilizando la Biblioteca no está restringido, y la salida de dicho programa está cubierta solo si su contenido constituye un trabajo basado en la Biblioteca (independientemente del uso de la Biblioteca en una herramienta para escribirlo). Si eso es cierto, depende de lo que haga la Biblioteca y del programa que la utiliza. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 1. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Puede copiar y distribuir copias literales de el código fuente completo de la Biblioteca a medida que lo reciba, en cualquier medio, siempre que publique de forma visible y adecuada en cada copia un aviso de copyright y una renuncia de garantía adecuados; mantenga intactos todos los avisos que se refieren a esta Licencia ya la ausencia de cualquier garantía; y distribuya una copia de esta Licencia junto con la Biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Usted puede cobrar una tarifa por el acto físico de transferir una copia, y puede, a opción suya, ofrecer una garantía de protección a cambio de una tarifa.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;2.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Puede modificar su copia o copias de la Biblioteca o cualquier parte de ella, formando así un trabajo basado en la Biblioteca, y copiar y distribuir dichas modificaciones o trabajos según los términos de la Sección 1 anterior, siempre que cumpla con todas estas condiciones : &lt;/span&gt; &lt;/p&gt;
&lt;ul style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt; &lt;li style = &quot;font-family: &apos; sans-serif &apos;; &quot; style = &quot;margin-top: 19px; margin-bottom: 0px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; a) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; El trabajo modificado debe ser una biblioteca de software. &lt;/span&gt; &lt;/li&gt;
&lt;li style = &quot;font-family: &apos;sans-serif&apos;;&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; b) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Debe hacer que los archivos modificados contengan avisos importantes que indiquen que cambió los archivos y fecha de cualquier cambio. &lt;/span&gt; &lt;/li&gt;
&lt;li style = &quot;font-family: &apos;sans-serif&apos;;&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; c) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Debe hacer que la totalidad del trabajo tenga licencia sin cargo para todos los terceros bajo los términos de esta Licencia. &lt;/span&gt; &lt;/li&gt;
&lt;li style = &quot;font-family: &apos;sans-serif&apos;;&quot; style = &quot;margin-top: 0px; margin-bottom: 19px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; d) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Si una instalación en la Biblioteca modificada se refiere a una función o una tabla de datos, suministrado por un programa de aplicación que utiliza la instalación, aparte de como un argumento pasado cuando se invoca la instalación, debe hacer un esfuerzo de buena fe para asegurarse de que, en el caso de que una aplicación no suministre dicha función o tabla, la instalación aún opera, y realiza cualquier parte de su propósito sigue siendo significativa. &lt;/span&gt; &lt;/li&gt; &lt;/ul&gt;
&lt;p style = &quot;margin-top: 15px; margin-bottom: 15px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 1; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; (Por ejemplo, una función en una biblioteca para calcular raíces cuadradas tiene un propósito que está completamente bien definido independientemente de la aplicación. Por lo tanto, la Subsección 2d requiere que cualquier aplicación sea suministrada la función o tabla utilizada por esta función debe ser opcional: si la aplicación no la proporciona, la función de raíz cuadrada aún debe calcular las raíces cuadradas.)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Estos requisitos se aplican a la obra modificada en su conjunto. Si las secciones identificables de ese trabajo no se derivan de la Biblioteca, y pueden considerarse razonablemente trabajos independientes e independientes en sí mismas, entonces esta Licencia y sus términos no se aplican a esas secciones cuando los distribuye como trabajos separados. Pero cuando distribuye las mismas secciones como parte de un todo, que es un trabajo basado en la Biblioteca, la distribución del todo debe estar en los términos de esta Licencia, cuyos permisos para otros licenciatarios se extienden a todo el conjunto y, por lo tanto, a cada uno. y cada parte, independientemente de quién lo escribió. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Por lo tanto, no es la intención de esta sección reclamar derechos o impugnar sus derechos a trabajar escritos completamente por usted; más bien, la intención es ejercer el derecho de controlar la distribución de trabajos derivados o colectivos basados ​​en la Biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Además, la mera agregación de otro trabajo no basado en la Biblioteca con la Biblioteca (o con un trabajo basado en la Biblioteca) en un volumen de un medio de almacenamiento o distribución no lo hace ponga el otro trabajo bajo el alcance de esta Licencia. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 3. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Puede optar por aplicar los términos de la Licencia Pública General GNU ordinaria en lugar de esta Licencia a una copia dada de la Biblioteca. Para hacer esto, debe modificar todos los avisos que se refieren a esta Licencia, de modo que se refieran a la Licencia Pública General de GNU ordinaria, versión 2, en lugar de a esta Licencia. (Si ha aparecido una versión más nueva que la versión 2 de la Licencia Pública General de GNU ordinaria, puede especificar esa versión si lo desea). No haga ningún otro cambio en estos avisos. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Una vez que se realiza este cambio en una copia dada, es irreversible para esa copia, por lo que la Licencia Pública General GNU ordinaria se aplica a todas las copias subsiguientes y trabajos derivados realizados a partir de esa copia.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Esta opción es útil cuando desea copiar parte del código de la Biblioteca en un programa que no es una biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 4. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Puede copiar y distribuir la Biblioteca ( o una parte o derivado de él, en la Sección 2) en código objeto o en forma ejecutable bajo los términos de las Secciones 1 y 2 anteriores, siempre que lo acompañe con el código fuente completo legible por máquina correspondiente, que debe ser distribuido bajo los términos de Las secciones 1 y 2 anteriores en un medio utilizado habitualmente para el intercambio de software. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Si la distribución del código del objeto se realiza ofreciendo acceso a la copia desde un lugar designado, el acceso equivalente para copiar el código fuente desde el mismo lugar satisface el requisito de distribuir la fuente código, aunque los terceros no están obligados a copiar la fuente junto con el código objeto. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 5. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Un programa que no contiene ningún derivado La parte de la Biblioteca, pero está diseñada para trabajar con la Biblioteca al compilarse o vincularse con ella, se denomina trabajo que utiliza la Biblioteca &amp; quot ;. Tal trabajo, de forma aislada, no es un trabajo derivado de la Biblioteca y, por lo tanto, queda fuera del alcance de esta Licencia. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Sin embargo, al vincular un trabajo &amp; quot; que utiliza la Biblioteca &amp; quot; con la Biblioteca crea un ejecutable que es un derivado de la Biblioteca (porque contiene partes de la Biblioteca), en lugar de un trabajo que usa la biblioteca &amp; quot ;. El ejecutable está cubierto por esta Licencia. La Sección 6 establece los términos para la distribución de tales ejecutables.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Cuando un &amp; quot; trabajo que utiliza la Biblioteca &amp; quot; utiliza material de un archivo de encabezado que forma parte de la Biblioteca, el código objeto para el trabajo puede ser un trabajo derivado de la Biblioteca, aunque el código fuente no lo sea. Si esto es cierto es especialmente significativo si el trabajo se puede vincular sin la Biblioteca, o si el trabajo es en sí mismo una biblioteca. El umbral para que esto sea cierto no está definido con precisión por la ley. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Si tal archivo de objeto usa solo parámetros numéricos, estructuras de datos y elementos de acceso, y macros pequeñas y funciones en línea pequeñas (diez líneas o menos de longitud), entonces el uso de el archivo de objeto no está restringido, independientemente de si es legalmente un trabajo derivado. (Los archivos ejecutables que contienen este código de objeto más partes de la Biblioteca aún se incluirán en la Sección 6). &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; De lo contrario, si el trabajo es un derivado de la Biblioteca, puede distribuir el código objeto para el trabajo según los términos de la Sección 6. Cualquier archivo ejecutable que contenga ese trabajo también está incluido en la Sección 6, estén o no vinculados directamente con la propia Biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 6. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Como excepción a las Secciones anteriores, también puede combinar o vincular un trabajo &amp; quot; que utiliza la Biblioteca &amp; quot; con la Biblioteca para producir un trabajo que contenga partes de la Biblioteca, y distribuir ese trabajo según los términos que usted elija, siempre que los términos permitan la modificación del trabajo para el uso propio del cliente y la ingeniería inversa para depurar dichas modificaciones.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Debe dar un aviso destacado con cada copia del trabajo que se utiliza en la Biblioteca y que la Biblioteca y su uso están cubiertos por esta Licencia. Debe proporcionar una copia de esta Licencia. Si el trabajo durante la ejecución muestra avisos de derechos de autor, debe incluir entre ellos el aviso de copyright de la Biblioteca, así como una referencia que indique al usuario la copia de esta Licencia. Además, debes hacer una de estas cosas: &lt;/span&gt; &lt;/p&gt;
&lt;ul style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt; &lt;li style = &quot;font-family: &apos; sans-serif &apos;; &quot; style = &quot;margin-top: 19px; margin-bottom: 0px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; a) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Acompañe el trabajo con el código fuente completo legible por máquina correspondiente para la Biblioteca, incluidos los cambios se utilizaron en el trabajo (que debe distribuirse en las Secciones 1 y 2 anteriores); y, si el trabajo es un ejecutable vinculado con la Biblioteca, con el trabajo completo &quot;legible por máquina&quot; que utiliza la Biblioteca como código de objeto y / o código fuente, para que el usuario pueda modificar la Biblioteca y luego volver a vincular para producir un ejecutable modificado que contiene la biblioteca modificada. (Se entiende que el usuario que cambia el contenido de los archivos de definiciones en la Biblioteca no necesariamente podrá recompilar la aplicación para usar las definiciones modificadas). &lt;/span&gt; &lt;/li&gt;
&lt;li style = &quot;font-family: &apos;sans-serif&apos;;&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; b) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Use un mecanismo de biblioteca compartida adecuado para enlazar con la Biblioteca. Un mecanismo adecuado es uno que (1) utiliza en tiempo de ejecución una copia de la biblioteca ya presente en el sistema informático del usuario, en lugar de copiar las funciones de la biblioteca en el ejecutable, y (2) funcionará correctamente con una versión modificada de la biblioteca, si el usuario instala uno, siempre que la versión modificada sea compatible con la interfaz con la versión con la que se realizó el trabajo. &lt;/span&gt; &lt;/li&gt;
&lt;li style = &quot;font-family: &apos;sans-serif&apos;;&quot; style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; c) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Acompañe el trabajo con una oferta por escrito, válida por al menos tres años, para dar el mismo usuario los materiales especificados en la subsección 6a, arriba, por un cargo que no supera el costo de realizar esta distribución.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;d)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Si la distribución del trabajo se realiza ofreciendo acceso a la copia desde un lugar designado, ofrezca un acceso equivalente para copiar los materiales especificados anteriormente desde el mismo lugar. &lt;/span&gt; &lt;/li&gt;
&lt;li style = &quot;font-family: &apos;sans-serif&apos;;&quot; style = &quot;margin-top: 0px; margin-bottom: 19px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; e) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Verifique que el usuario ya haya recibido una copia de estos materiales o que ya haya enviado este usuario es una copia. &lt;/span&gt; &lt;/li&gt; &lt;/ul&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Para un ejecutable, la forma requerida del trabajo &amp; quot; que utiliza la Biblioteca &amp; quot; debe incluir todos los datos y programas de utilidad necesarios para reproducir el ejecutable desde él. Sin embargo, como excepción especial, los materiales a distribuir no necesitan incluir nada que se distribuya normalmente (en forma de fuente o binario) con los componentes principales (compilador, kernel, etc.) del sistema operativo en el que se ejecuta el ejecutable. , a menos que ese componente acompañe al ejecutable. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Puede suceder que este requisito contradiga las restricciones de licencia de otras bibliotecas propietarias que normalmente no acompañan al sistema operativo. Tal contradicción significa que no puede usarlos a ellos y a la Biblioteca juntos en un ejecutable que distribuya.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;7.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; Puede ubicar las instalaciones de la biblioteca que son un trabajo basado en la biblioteca lado a lado en una sola biblioteca junto con otras instalaciones de la biblioteca que no están cubiertas por esta Licencia, y distribuir dicha biblioteca combinada, siempre que la distribución separada del trabajo basada en la Biblioteca y de las demás instalaciones de la biblioteca están permitidas, y siempre que haga estas dos cosas: &lt;/span&gt; &lt;/p&gt;
&lt;ul style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt; &lt;li style = &quot;font-family: &apos; sans-serif &apos;; &quot; style = &quot;margin-top: 19px; margin-bottom: 0px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; a) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Acompañe la biblioteca combinada con una copia del mismo trabajo basado en la Biblioteca, sin combinar Cualquier otra biblioteca. Esto debe distribuirse según los términos de las Secciones anteriores. &lt;/span&gt; &lt;/li&gt;
&lt;li style = &quot;font-family: &apos;sans-serif&apos;;&quot; style = &quot;margin-top: 0px; margin-bottom: 19px; margin-left: 38px; margin-right: 19px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font -size: 16px; font-weight: 600; &quot;&gt; b) &lt;/span&gt; &lt;span style =&quot; font-size: 16px; &quot;&gt; Dé un aviso destacado a la biblioteca combinada sobre el hecho de que parte de ella se basa en el trabajo en la Biblioteca, y explicando dónde encontrar la forma no combinada que acompaña al mismo trabajo. &lt;/span&gt; &lt;/li&gt; &lt;/ul&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 8. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; No puede copiar, modificar, sublicenciar , haga un enlace o distribuya la Biblioteca, excepto lo dispuesto expresamente en esta Licencia. Cualquier intento de copiar, modificar, sublicenciar, vincular o distribuir la Biblioteca de otra manera será nulo y terminará automáticamente sus derechos bajo esta Licencia. Sin embargo, a las partes que hayan recibido copias o derechos de usted bajo esta Licencia no se les dará por terminadas sus licencias siempre y cuando dichas partes sigan cumpliendo con todos los requisitos.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;9.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; No está obligado a aceptar esta Licencia, ya que no la ha firmado. Sin embargo, nada más le otorga permiso para modificar o distribuir la Biblioteca o sus trabajos derivados. Estas acciones están prohibidas por la ley si no acepta esta Licencia. Por lo tanto, al modificar o distribuir la Biblioteca (o cualquier trabajo basado en la Biblioteca), usted indica que acepta esta Licencia para hacerlo, y todos sus términos y condiciones para copiar, distribuir o modificar la Biblioteca o los trabajos basados ​​en ella. &lt; / span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 10. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Cada vez que redistribuya la Biblioteca (o cualquier trabajo basado en la Biblioteca), el destinatario recibe automáticamente una licencia del licenciador original para copiar, distribuir, vincular o modificar la Biblioteca sujeto a estos términos y condiciones. No puede imponer restricciones adicionales al ejercicio de los derechos de los beneficiarios otorgados en este documento. Usted no es responsable de hacer cumplir el cumplimiento de esta Licencia por parte de terceros. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 11. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; If, como consecuencia de un tribunal Sentencia o alegación de infracción de patente o por cualquier otro motivo (no limitado a cuestiones de patentes), se le imponen condiciones (ya sea por orden judicial, acuerdo o de otra manera) que contradigan las condiciones de esta Licencia, no lo eximen de las condiciones. de esta Licencia. Si no puede realizar la distribución para satisfacer simultáneamente sus obligaciones bajo esta Licencia y cualquier otra obligación pertinente, como consecuencia, no podrá distribuir la Biblioteca en absoluto. Por ejemplo, si una licencia de patente no permitiera la redistribución de la Biblioteca de todos los que reciben copias directa o indirectamente a través de usted, la única forma en que podría satisfacerla y esta Licencia sería abstenerse totalmente de la distribución de la Biblioteca. Biblioteca. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Si alguna parte de esta sección se considera inválida o inaplicable en cualquier circunstancia particular, se pretende que el resto de la sección se aplique, y la sección en su totalidad se debe aplicar en otras circunstancias&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;No es el propósito de esta sección inducirlo a infringir ninguna patente u otros reclamos de derechos de propiedad o impugnar la validez de dichos reclamos; Esta sección tiene el único propósito de proteger la integridad del sistema de distribución de software libre que se implementa mediante prácticas de licencia pública. Muchas personas han hecho contribuciones generosas a la amplia gama de software distribuido a través de ese sistema, confiando en la aplicación consistente de ese sistema; Depende del autor / donante decidir si está dispuesto a distribuir software a través de cualquier otro sistema y un licenciatario no puede imponer esa elección. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Esta sección pretende aclarar completamente lo que se cree que es una consecuencia del resto de esta Licencia. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 12. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Si la distribución y / o uso de la Biblioteca está restringida en ciertos países ya sea por patentes o por interfaces con derechos de autor, el titular original de los derechos de autor que coloca a la Biblioteca bajo esta Licencia puede agregar una limitación de distribución geográfica explícita excluyendo esos países, de modo que la distribución se permite solo en o entre países no excluidos. . En tal caso, esta Licencia incorpora la limitación como si estuviera escrita en el cuerpo de esta Licencia. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 13. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; La Free Software Foundation puede publicar revisados ​​y / o nuevas versiones de la Licencia Pública General Menor de vez en cuando. Estas nuevas versiones serán similares en espíritu a la versión actual, pero pueden diferir en detalle para abordar nuevos problemas o inquietudes. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; A cada versión se le asigna un número de versión distintivo. Si la Biblioteca especifica un número de versión de esta Licencia que se le aplica y &amp; quot; cualquier versión posterior &amp; quot ;, tiene la opción de seguir los términos y condiciones de esa versión o de cualquier versión posterior publicada por la Free Software Foundation. Si la Biblioteca no especifica un número de versión de licencia, puede elegir cualquier versión publicada por la Free Software Foundation.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;14.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; Si desea incorporar partes de la Biblioteca a otros programas gratuitos cuyas condiciones de distribución son incompatibles con estos, escriba al autor para pedirle permiso. Para el software cuyo copyright es Free Software Foundation, escriba a Free Software Foundation; A veces hacemos excepciones para esto. Nuestra decisión se guiará por los dos objetivos de preservar el estado gratuito de todos los derivados de nuestro software libre y de promover el uso compartido y la reutilización del software en general. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; SIN GARANTÍA &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 15. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; PORQUE LA BIBLIOTECA TIENE LICENCIA GRATUITA , NO EXISTE GARANTÍA PARA LA BIBLIOTECA, HASTA EL GRADO PERMITIDO POR LA LEY APLICABLE. EXCEPTO CUANDO OTRA MANERA ESTABLECIDO EN ESCRIBIR LOS TITULARES DEL DERECHO DE AUTOR Y / O OTRAS PARTES PROPORCIONAN LA BIBLIOTECA &quot;COMO ESTÁ&quot; SIN GARANTÍA DE NINGÚN TIPO, YA SEA EXPRESA O IMPLÍCITA, INCLUYENDO, PERO NO LIMITADO A, LAS GARANTÍAS IMPLÍCITAS DE COMERCIABILIDAD Y ADECUACIÓN PARA UN PROPÓSITO PARTICULAR. TODO EL RIESGO EN CUANTO A LA CALIDAD Y EL RENDIMIENTO DE LA BIBLIOTECA ESTÁ CON USTED. DEBE QUE LA BIBLIOTECA PRUEBA DEFECTUOSO, USTED ASUME EL COSTO DE TODO EL SERVICIO, LA REPARACIÓN O LA CORRECCIÓN NECESARIOS. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600;&quot;&gt; 16. &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; EN NINGÚN CASO, A MENOS QUE ES NECESARIO LA LEY APLICABLE O ESTÁ DE ACUERDO EN ESCRIBIR CUALQUIER RESPONSABLE DE DERECHOS DE AUTOR, O CUALQUIER OTRA PARTE QUE PUEDE MODIFICAR Y / O REDISTRAR LA BIBLIOTECA PERMITIDA ANTERIORMENTE, SERÁ RESPONSABLE DE DAÑOS POR ARCHIVOS, INCLUYENDO DAÑOS GENERALES, ESPECIALES, INCIDENTALES O CONSEQUÍTICOS, DEFECTUIDOS EN EL ARTÍCULO NO SE PUEDE UTILIZAR LA BIBLIOTECA (INCLUYENDO PERO NO LIMITADA A LA PÉRDIDA DE DATOS O LOS DATOS QUE SE RENDIDOS NO PRECISO O PÉRDIDAS SOSTENIDAS POR USTED O TERCERAS PARTES O LA FALTA DE LA BIBLIOTECA PARA OPERAR CON CUALQUIER OTRO SOFTWARE), INCLUSO SI HAY ALGÚN VENDEDOR U OTRA PARTE. AVISO DE LA POSIBILIDAD DE DICHOS DAÑOS.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;FIN DE LOS TÉRMINOS Y CONDICIONES &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 15px; margin-bottom: 15px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;a name = &quot;SEC4&quot;&gt; &lt;/a&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600; color: # 333333;&quot;&gt; H &lt;/span&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;; font-weight: 600; color: # 333333; &quot;&gt; Cómo aplicar estos términos a sus nuevas bibliotecas &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Si desarrolla una nueva biblioteca y desea que sea de la mayor utilidad posible para el público, le recomendamos que sea un software gratuito que todos puedan redistribuir y cambiar. Puede hacerlo permitiendo la redistribución bajo estos términos (o, alternativamente, bajo los términos de la Licencia Pública General ordinaria). &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; Para aplicar estos términos, adjunte los siguientes avisos a la biblioteca. Es más seguro adjuntarlos al inicio de cada archivo fuente para transmitir de manera más efectiva la exclusión de la garantía; y cada archivo debe tener al menos el &amp; quot; copyright &amp; quot; línea y un puntero donde se encuentra el aviso completo. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;; font-style: italic;&quot;&gt; una línea para dar el nombre de la biblioteca y una idea de lo que hace. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Copyright (C) &lt;/span&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;; font-style: italic;&quot;&gt; year &lt;/span&gt; &lt;span style = &quot; font-family: &apos;monospace&apos;; &quot;&gt; &lt;/span&gt; &lt;span style =&quot; font-family: &apos;monospace&apos;; font-style: italic; &quot;&gt; nombre del autor &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent : 0px; font-family: &apos;monospace&apos;; font-style: italic; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Esta biblioteca es software libre; puedes redistribuirlo y / o&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;modifíquelo bajo los términos del Público General Menor GNU &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt;&gt; licencia publicada por la Free Software Foundation; ya sea &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; versión 2.1 de la Licencia, o (a su elección) cualquier versión posterior. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent : 0px; font-family: &apos;monospace&apos;; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Esta biblioteca se distribuye con la esperanza de que sea útil, &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; pero SIN NINGUNA GARANTÍA; sin siquiera la garantía implícita de &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; MERCHANTABILITY o FITNESS PARA UN PROPÓSITO PARTICULAR. Ver el GNU &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Lesser General Public License para más detalles. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent : 0px; font-family: &apos;monospace&apos;; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Debería haber recibido una copia del Público General Menor de GNU&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Licencia junto con esta biblioteca; si no, escriba al Software Libre &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 15px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 EE. UU. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; También agregue información sobre cómo contactarlo por correo electrónico y en papel. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; También debe hacer que su empleador (si trabaja como programador) o su escuela, si corresponde, firme un &amp; quot; renuncia de derechos de autor &amp; quot; para la biblioteca, si es necesario. Aquí hay una muestra; alterar los nombres: &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Yoyodyne, Inc., por la presente renuncia a todo interés de copyright en &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; la biblioteca `Frob &apos;(una biblioteca para ajustes de mandos) escrita &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; por James Random Hacker. &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;- qt -agraph-type: empty; margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent : 0px; font-family: &apos;monospace&apos;; &quot;&gt; &lt;br /&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;; font-style: italic;&quot;&gt; firma de Ty Coon &lt;/span&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt;, 1 de abril de 1990 &lt;/span&gt; &lt;/ p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 15px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;monospace&apos;;&quot;&gt; Ty Coon, Presidente de Vice &lt;/span&gt; &lt;/p&gt;
&lt;p style = &quot;margin-top: 19px; margin-bottom: 19px; margin-left: 0px; margin-right: 0px; -qt-block-indent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-family: &apos;sans-serif&apos;;&quot;&gt; ¡Eso es todo!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>LimeReport::AlignmentPropItem</name>
    <message>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Derecha</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <source>Justify</source>
        <translation>Justificado</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <source>Botom</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <source>horizontal</source>
        <translation>horizontal</translation>
    </message>
    <message>
        <source>vertical</source>
        <translation>vertical</translation>
    </message>
</context>
<context>
    <name>LimeReport::BandDesignIntf</name>
    <message>
        <source> connected to </source>
        <translation>conectado a</translation>
    </message>
    <message>
        <source>Bring to top</source>
        <translation>Traer al frente</translation>
    </message>
    <message>
        <source>Send to back</source>
        <translation>Enviar al fondo</translation>
    </message>
    <message>
        <source>Auto height</source>
        <translation>Alto automático</translation>
    </message>
    <message>
        <source>Splittable</source>
        <translation>Separable</translation>
    </message>
    <message>
        <source>DataBand</source>
        <translation>Banda de Datos</translation>
    </message>
    <message>
        <source>DataHeaderBand</source>
        <translation>Banda de datos Encabezado</translation>
    </message>
    <message>
        <source>DataFooterBand</source>
        <translation>Banda de datos Pie</translation>
    </message>
    <message>
        <source>ReportHeader</source>
        <translation>Encabezado del reporte</translation>
    </message>
    <message>
        <source>ReportFooter</source>
        <translation>Pie del reporte</translation>
    </message>
    <message>
        <source>PageHeader</source>
        <translation>Encabezado de Página</translation>
    </message>
    <message>
        <source>PageFooter</source>
        <translation>Pie de página</translation>
    </message>
    <message>
        <source>SubDetailBand</source>
        <translation>Banda de Sub detalle</translation>
    </message>
    <message>
        <source>SubDetailHeaderBand</source>
        <translation>Banda de sub detalle Encabezado</translation>
    </message>
    <message>
        <source>SubDetailFooterBand</source>
        <translation>Banda de sub detalle Pie</translation>
    </message>
    <message>
        <source>GroupBandHeader</source>
        <translation>Banda de grupo Encabezado</translation>
    </message>
    <message>
        <source>GroupBandFooter</source>
        <translation>Banda de grupo Pie</translation>
    </message>
    <message>
        <source>TearOffBand</source>
        <translation>Banda de cortado</translation>
    </message>
    <message>
        <source>Keep bottom space</source>
        <translation>Mantener espacio inferior</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Print if empty</source>
        <translation>Imprimir si está vacío</translation>
    </message>
    <message>
        <source>Keep top space</source>
        <translation>Conservar. esp. superior</translation>
    </message>
</context>
<context>
    <name>LimeReport::BaseDesignIntf</name>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Bring to top</source>
        <translation>Traer al frente</translation>
    </message>
    <message>
        <source>Send to back</source>
        <translation>Enviar atras</translation>
    </message>
    <message>
        <source>No borders</source>
        <translation>Sin bordes</translation>
    </message>
    <message>
        <source>All borders</source>
        <translation>Todos los bordes</translation>
    </message>
    <message>
        <source>Create Horizontal Layout</source>
        <translation>Crear diseño horizontal</translation>
    </message>
    <message>
        <source>Create Vertical Layout</source>
        <translation>Crear diseño vertical</translation>
    </message>
    <message>
        <source>Lock item geometry</source>
        <translation>Asegurar geomatría de objeto</translation>
    </message>
</context>
<context>
    <name>LimeReport::ConnectionDesc</name>
    <message>
        <source>defaultConnection</source>
        <translation>Conexión por defecto</translation>
    </message>
</context>
<context>
    <name>LimeReport::ConnectionDialog</name>
    <message>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <source>Connection Name</source>
        <translation>Nombre de conexión</translation>
    </message>
    <message>
        <source>Server </source>
        <translation>Servidor</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Base de Datos</translation>
    </message>
    <message>
        <source>Auto connect</source>
        <translation>Auto conectar</translation>
    </message>
    <message>
        <source>Check connection</source>
        <translation>Probar conexión</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Connection succsesfully established!</source>
        <translation>Conexión establecida satisfactoriamente!</translation>
    </message>
    <message>
        <source>Connection Name is empty</source>
        <translation>El Nombre de la conexión esta vacía</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation></translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation></translation>
    </message>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>Connection with name </source>
        <translation>Conexión con nombre </translation>
    </message>
    <message>
        <source>Use default application connection</source>
        <translation>Utilice la conexión de aplicación predeterminada</translation>
    </message>
    <message>
        <source>defaultConnection</source>
        <translation>Conexión por defecto</translation>
    </message>
    <message>
        <source> already exists! </source>
        <translation>¡ya existe!</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <source>Don&apos;t keep credentials in lrxml</source>
        <translation>No mantener credentals en el lrxml</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataBand</name>
    <message>
        <source>Data</source>
        <translation>Datos</translation>
    </message>
    <message>
        <source>Use alternate background color</source>
        <translation>Usar color de fondo alternativo</translation>
    </message>
    <message>
        <source>Keep footer together</source>
        <translation>Mantener pie de página junto</translation>
    </message>
    <message>
        <source>Keep subdetail together</source>
        <translation>Mantener subdetalles juntos</translation>
    </message>
    <message>
        <source>Slice last row</source>
        <translation>Cortar la última fila</translation>
    </message>
    <message>
        <source>Start from new page</source>
        <translation>Empezar desde nueva página</translation>
    </message>
    <message>
        <source>Start new page</source>
        <translation>Inciar nueva página</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataBrowser</name>
    <message>
        <source>Attention</source>
        <translation>Atención</translation>
    </message>
    <message>
        <source>Datasources</source>
        <translation>Orígenes de Datos</translation>
    </message>
    <message>
        <source>Add database connection</source>
        <translation>Agregar conexion a base de datos</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Add new datasource</source>
        <translation>Agregar origen de datos</translation>
    </message>
    <message>
        <source>View data</source>
        <translation>Ver datos</translation>
    </message>
    <message>
        <source>Change datasource</source>
        <translation>Cambiar origen de datos</translation>
    </message>
    <message>
        <source>Delete datasource</source>
        <translation>Eliminar origen de datos</translation>
    </message>
    <message>
        <source>Show error</source>
        <translation>Mostrar error</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation></translation>
    </message>
    <message>
        <source>Add new variable</source>
        <translation>Agregar variable</translation>
    </message>
    <message>
        <source>Edit variable</source>
        <translation>Editar variable</translation>
    </message>
    <message>
        <source>Delete variable</source>
        <translation>Borrarvariable</translation>
    </message>
    <message>
        <source>System variables</source>
        <translation>Variables del sistema</translation>
    </message>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>Grab variable</source>
        <translation>Capturar variable</translation>
    </message>
    <message>
        <source>Report variables</source>
        <translation>Variables de informe</translation>
    </message>
    <message>
        <source>External variables</source>
        <translation>Variables externas</translation>
    </message>
    <message>
        <source>Do you really want to delete &quot;%1&quot; connection?</source>
        <translation>Realmente quieres eliminar la conexión &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Do you really want to delete &quot;%1&quot; datasource?</source>
        <translation>¿Realmente quieres eliminar el origen de datos &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Do you really want to delete variable &quot;%1&quot;?</source>
        <translation>¿Realmente quieres eliminar la variable &quot;%1&quot;?</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataFooterBand</name>
    <message>
        <source>DataFooter</source>
        <translation>Pie de datos</translation>
    </message>
    <message>
        <source>Print always</source>
        <translation>Imprimir siempre</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataHeaderBand</name>
    <message>
        <source>DataHeader</source>
        <translation>Encabezado de datos</translation>
    </message>
    <message>
        <source>Reprint on each page</source>
        <translation>Re-imprimir en cada página</translation>
    </message>
    <message>
        <source>Repeat on each row</source>
        <translation>Repetir en cada fila</translation>
    </message>
    <message>
        <source>Print always</source>
        <translation>Imprimir simpre</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataSourceManager</name>
    <message>
        <source>Connection &quot;%1&quot; is not open</source>
        <translation>La conexión &quot;%1&quot; no está abierta</translation>
    </message>
    <message>
        <source>Variable &quot;%1&quot; not found!</source>
        <translation>¡No se encontró la variable &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>invalid connection</source>
        <translation>conexión inválida</translation>
    </message>
    <message>
        <source>Database &quot;%1&quot; not found</source>
        <translation>No se encontró la base de datos &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Datasource &quot;%1&quot; not found!</source>
        <translation>¡Fuente de datos &quot;%1&quot; no encontrada!</translation>
    </message>
    <message>
        <source>Connection with name &quot;%1&quot; already exists!</source>
        <translation>¡La conexión con el nombre &quot;%1&quot; ya existe!</translation>
    </message>
    <message>
        <source>Datasource with name &quot;%1&quot; already exists!</source>
        <translation>¡La fuente de datos con nombre &quot;%1&quot; ya existe!</translation>
    </message>
    <message>
        <source>Unknown parameter &quot;%1&quot; for variable &quot;%2&quot; found!</source>
        <translation>Se encontró un parámetro desconocido &quot;%1&quot; para la variable &quot;%2&quot;.</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataSourceModel</name>
    <message>
        <source>Datasources</source>
        <translation>Orígenes de Datos</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation></translation>
    </message>
    <message>
        <source>External variables</source>
        <translation>Variables externas</translation>
    </message>
</context>
<context>
    <name>LimeReport::DialogDesignerManager</name>
    <message>
        <source>Edit Widgets</source>
        <translation>Editar objeto</translation>
    </message>
    <message>
        <source>Widget Box</source>
        <translation>Caja de objeto</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>Inspector de objeto</translation>
    </message>
    <message>
        <source>Property Editor</source>
        <translation>Editor de propiedades</translation>
    </message>
    <message>
        <source>Signals &amp;&amp; Slots Editor</source>
        <translation>Editor de Señales y eventos</translation>
    </message>
    <message>
        <source>Resource Editor</source>
        <translation>Editor de recursos</translation>
    </message>
    <message>
        <source>Action Editor</source>
        <translation>Editor de acciones</translation>
    </message>
</context>
<context>
    <name>LimeReport::EnumPropItem</name>
    <message>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Apaisado (Horizontal)</translation>
    </message>
    <message>
        <source>NoneAutoWidth</source>
        <translation>Sin ancho automático</translation>
    </message>
    <message>
        <source>MaxWordLength</source>
        <translation>Max. largo palabra</translation>
    </message>
    <message>
        <source>MaxStringLength</source>
        <translation>Max. Largo cadena</translation>
    </message>
    <message>
        <source>TransparentMode</source>
        <translation>Modo transparente</translation>
    </message>
    <message>
        <source>OpaqueMode</source>
        <translation>Modo opaco</translation>
    </message>
    <message>
        <source>Angle0</source>
        <translation>Angulo 0</translation>
    </message>
    <message>
        <source>Angle90</source>
        <translation>Angulo 90</translation>
    </message>
    <message>
        <source>Angle180</source>
        <translation>Angulo 180</translation>
    </message>
    <message>
        <source>Angle270</source>
        <translation>Angulo 270</translation>
    </message>
    <message>
        <source>Angle45</source>
        <translation>Angulo 45</translation>
    </message>
    <message>
        <source>Angle315</source>
        <translation>Angulo 315</translation>
    </message>
    <message>
        <source>DateTime</source>
        <translation>FechaHora</translation>
    </message>
    <message>
        <source>Double</source>
        <translation>Doble</translation>
    </message>
    <message>
        <source>NoBrush</source>
        <translation>Sin brocha</translation>
    </message>
    <message>
        <source>SolidPattern</source>
        <translation>Patrón sólido</translation>
    </message>
    <message>
        <source>Dense1Pattern</source>
        <translation>Patrón Denso1</translation>
    </message>
    <message>
        <source>Dense2Pattern</source>
        <translation>Patrón Denso2</translation>
    </message>
    <message>
        <source>Dense3Pattern</source>
        <translation>Patrón Denso3</translation>
    </message>
    <message>
        <source>Dense4Pattern</source>
        <translation>Patrón Denso4</translation>
    </message>
    <message>
        <source>Dense5Pattern</source>
        <translation>Patrón Denso5</translation>
    </message>
    <message>
        <source>Dense6Pattern</source>
        <translation>Patrón Denso6</translation>
    </message>
    <message>
        <source>Dense7Pattern</source>
        <translation>Patrón Denso7</translation>
    </message>
    <message>
        <source>HorPattern</source>
        <translation>Patrón Horizontal</translation>
    </message>
    <message>
        <source>VerPattern</source>
        <translation>Patrón Vertical</translation>
    </message>
    <message>
        <source>CrossPattern</source>
        <translation>Patrón cruzado</translation>
    </message>
    <message>
        <source>BDiagPattern</source>
        <translation>Patrón Diag.B</translation>
    </message>
    <message>
        <source>FDiagPattern</source>
        <translation>Patrón Diag.F</translation>
    </message>
    <message>
        <source>LeftToRight</source>
        <translation>Izquierda A Derecha</translation>
    </message>
    <message>
        <source>RightToLeft</source>
        <translation>Derecha A Izquierda</translation>
    </message>
    <message>
        <source>LayoutDirectionAuto</source>
        <translation>Dirección diseño automática</translation>
    </message>
    <message>
        <source>LeftItemAlign</source>
        <translation>Alinear objeto a la izquierda</translation>
    </message>
    <message>
        <source>RightItemAlign</source>
        <translation>Alinear objeto a la derecha</translation>
    </message>
    <message>
        <source>CenterItemAlign</source>
        <translation>Centrar objeto</translation>
    </message>
    <message>
        <source>ParentWidthItemAlign</source>
        <translation>Alinear objeto con acho de padre</translation>
    </message>
    <message>
        <source>DesignedItemAlign</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <source>HorizontalLine</source>
        <translation>Linea horizontal</translation>
    </message>
    <message>
        <source>VerticalLine</source>
        <translation>Linea vertical</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Rectangulo</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>Band</source>
        <translation>Banda</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation></translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation></translation>
    </message>
    <message>
        <source>VerticalUniform</source>
        <translation>Vertical uniforme</translation>
    </message>
    <message>
        <source>Pie</source>
        <translation>Pastel</translation>
    </message>
    <message>
        <source>VerticalBar</source>
        <translation>Barra vertical</translation>
    </message>
    <message>
        <source>HorizontalBar</source>
        <translation>Barra horizontal</translation>
    </message>
    <message>
        <source>LegendAlignTop</source>
        <translation>Alinear Leyenda Arriba</translation>
    </message>
    <message>
        <source>LegendAlignCenter</source>
        <translation>Centrar leyenda</translation>
    </message>
    <message>
        <source>LegendAlignBottom</source>
        <translation>Alinear Leyenda Abajo</translation>
    </message>
    <message>
        <source>TitleAlignLeft</source>
        <translation>Alinear titulo a la izquierda</translation>
    </message>
    <message>
        <source>TitleAlignRight</source>
        <translation>Alinear titulo a la derecha</translation>
    </message>
    <message>
        <source>TitleAlignCenter</source>
        <translation>Centrar titulo</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Diseño</translation>
    </message>
    <message>
        <source>Table</source>
        <translation>Tabla</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Milimetros</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Pulgadas</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Estirar</translation>
    </message>
    <message>
        <source>Split</source>
        <translation>Dividir</translation>
    </message>
</context>
<context>
    <name>LimeReport::FlagsPropItem</name>
    <message>
        <source>NoLine</source>
        <translation>Sin borde</translation>
    </message>
    <message>
        <source>TopLine</source>
        <translation>Borde superior</translation>
    </message>
    <message>
        <source>BottomLine</source>
        <translation>Borde inferior</translation>
    </message>
    <message>
        <source>LeftLine</source>
        <translation>Borde izquierdo</translation>
    </message>
    <message>
        <source>RightLine</source>
        <translation>Borde derecho</translation>
    </message>
    <message>
        <source>AllLines</source>
        <translation>Todos los bordes</translation>
    </message>
</context>
<context>
    <name>LimeReport::FontEditorWidget</name>
    <message>
        <source>Font bold</source>
        <translation>Negrita</translation>
    </message>
    <message>
        <source>Font Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <source>Font Underline</source>
        <translation>Subrayada</translation>
    </message>
</context>
<context>
    <name>LimeReport::FontPropItem</name>
    <message>
        <source>bold</source>
        <translation>negrita</translation>
    </message>
    <message>
        <source>italic</source>
        <translation>cursiva</translation>
    </message>
    <message>
        <source>underline</source>
        <translation>subrayada</translation>
    </message>
    <message>
        <source>size</source>
        <translation>tamaño</translation>
    </message>
    <message>
        <source>family</source>
        <translation>familia</translation>
    </message>
</context>
<context>
    <name>LimeReport::GroupBandFooter</name>
    <message>
        <source>GroupFooter</source>
        <translation>Pie de grupo</translation>
    </message>
</context>
<context>
    <name>LimeReport::GroupBandHeader</name>
    <message>
        <source>GroupHeader</source>
        <translation>Encabezado de grupo</translation>
    </message>
    <message>
        <source>Group field not found</source>
        <translation>Campo de grupo no encontrado</translation>
    </message>
    <message>
        <source>Datasource &quot;%1&quot; not found!</source>
        <translation>¡Fuente de datos &quot;%1&quot; no encontrada!</translation>
    </message>
</context>
<context>
    <name>LimeReport::GroupFunction</name>
    <message>
        <source>Field &quot;%1&quot; not found</source>
        <translation>Campo &quot;%1&quot; no encontrado</translation>
    </message>
    <message>
        <source>Variable &quot;%1&quot; not found</source>
        <translation>Variable &quot;%1&quot; no encontrada</translation>
    </message>
    <message>
        <source>Item &quot;%1&quot; not found</source>
        <translation>Objeto &quot;%1&quot; no encontrado</translation>
    </message>
    <message>
        <source>Wrong script syntax &quot;%1&quot; </source>
        <translation>Sintaxis de la secuencia de comandos incorrecta &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>LimeReport::ImageItem</name>
    <message>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>Marca de agua</translation>
    </message>
    <message>
        <source>Ext.</source>
        <translation>Ext.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Images (*.gif *.icns *.ico *.jpeg *.tga *.tiff *.wbmp *.webp *.png *.jpg *.bmp);;All(*.*)</source>
        <translation>Imágenes (*.gif *.icns *.ico *.jpeg *.tga *.tiff *.wbmp *.webp *.png *.jpg *.bmp) ;; Todas (*.*)</translation>
    </message>
</context>
<context>
    <name>LimeReport::ItemLocationPropItem</name>
    <message>
        <source>Band</source>
        <translation>Banda</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
</context>
<context>
    <name>LimeReport::ItemsAlignmentEditorWidget</name>
    <message>
        <source>Bring to top</source>
        <translation>Traer al frente</translation>
    </message>
    <message>
        <source>Send to back</source>
        <translation>Enviar al fondo</translation>
    </message>
    <message>
        <source>Align to left</source>
        <translation>Alinear a la izquierda</translation>
    </message>
    <message>
        <source>Align to right</source>
        <translation>Alinear a la derecha</translation>
    </message>
    <message>
        <source>Align to vertical center</source>
        <translation>Centrar verticalmente</translation>
    </message>
    <message>
        <source>Align to top</source>
        <translation>Alinear arriba</translation>
    </message>
    <message>
        <source>Align to bottom</source>
        <translation>Alinear abajo</translation>
    </message>
    <message>
        <source>Align to horizontal center</source>
        <translation>Centrar horizontalmente</translation>
    </message>
    <message>
        <source>Set same height</source>
        <translation>Fijar mismo alto</translation>
    </message>
    <message>
        <source>Set same width</source>
        <translation>Fijar mismo ancho</translation>
    </message>
</context>
<context>
    <name>LimeReport::ItemsBordersEditorWidget</name>
    <message>
        <source>Top line</source>
        <translation>Linea superior</translation>
    </message>
    <message>
        <source>Bottom line</source>
        <translation>Linea inferior</translation>
    </message>
    <message>
        <source>Left line</source>
        <translation>Linea izquierda</translation>
    </message>
    <message>
        <source>Right line</source>
        <translation>Linea derecha</translation>
    </message>
    <message>
        <source>No borders</source>
        <translation>Sin bordes</translation>
    </message>
    <message>
        <source>All borders</source>
        <translation>Todos los bordes</translation>
    </message>
</context>
<context>
    <name>LimeReport::MasterDetailProxyModel</name>
    <message>
        <source>Field: &quot;%1&quot; not found in &quot;%2&quot; child datasource</source>
        <translation>Campo: &quot;%1&quot; no ha encontrado en la fuente de datos secundaria &quot;%2&quot;</translation>
    </message>
    <message>
        <source>Field: &quot;%1&quot; not found in &quot;%2&quot; master datasource</source>
        <translation>Campo: &quot;%1&quot; no encontrado en la fuente de datos maestra &quot;%2&quot;</translation>
    </message>
</context>
<context>
    <name>LimeReport::ModelToDataSource</name>
    <message>
        <source>model is destroyed</source>
        <translation>modelo esta destruido</translation>
    </message>
</context>
<context>
    <name>LimeReport::ObjectBrowser</name>
    <message>
        <source>Objects</source>
        <translation>Objetos</translation>
    </message>
</context>
<context>
    <name>LimeReport::ObjectInspectorWidget</name>
    <message>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtrar</translation>
    </message>
    <message>
        <source>Translate properties</source>
        <translation>Traducir propiedades</translation>
    </message>
</context>
<context>
    <name>LimeReport::PDFExporter</name>
    <message>
        <source>Export to PDF</source>
        <translation>Exportar a PDF</translation>
    </message>
</context>
<context>
    <name>LimeReport::PageFooter</name>
    <message>
        <source>Page Footer</source>
        <translation>Pie de página</translation>
    </message>
    <message>
        <source>Print on first page</source>
        <translation>Imprimir en primera página</translation>
    </message>
    <message>
        <source>Print on last page</source>
        <translation>Imprimir en última página</translation>
    </message>
</context>
<context>
    <name>LimeReport::PageHeader</name>
    <message>
        <source>Page Header</source>
        <translation>Encabezado de página</translation>
    </message>
</context>
<context>
    <name>LimeReport::PageItemDesignIntf</name>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Page is TOC</source>
        <translation>Página es TOC</translation>
    </message>
    <message>
        <source>Reset page number</source>
        <translation>Restablecer número de página</translation>
    </message>
    <message>
        <source>Full page</source>
        <translation>Página completa</translation>
    </message>
    <message>
        <source>Set page size to printer</source>
        <translation>Establecer el tamaño de página a la impresora</translation>
    </message>
</context>
<context>
    <name>LimeReport::PreviewReportWidget</name>
    <message>
        <source>Form</source>
        <translation>Desde</translation>
    </message>
    <message>
        <source>Report file name</source>
        <translation>Nombre del archivo del reporte</translation>
    </message>
    <message>
        <source>%1 file name</source>
        <translation>%1 nombre de archivo</translation>
    </message>
</context>
<context>
    <name>LimeReport::PreviewReportWindow</name>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <source>Report</source>
        <translation>Reporte</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <source>Prior Page</source>
        <translation>Página anterior</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Página siguiente</translation>
    </message>
    <message>
        <source>Close Preview</source>
        <translation>Cerrar vista previa</translation>
    </message>
    <message>
        <source>Edit Mode</source>
        <translation>Modo edición</translation>
    </message>
    <message>
        <source>Save to file</source>
        <translation>Guardar en archivo</translation>
    </message>
    <message>
        <source>Show errors</source>
        <translation>Mostrar errores</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>Primera página</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>Primera página</translation>
    </message>
    <message>
        <source>Last Page</source>
        <translation>Ultima página</translation>
    </message>
    <message>
        <source>Print To PDF</source>
        <translation>Imprimir en PDF</translation>
    </message>
    <message>
        <source>Page: </source>
        <translation>Página: </translation>
    </message>
    <message>
        <source> of %1</source>
        <translation> de %1</translation>
    </message>
    <message>
        <source>Fit page width</source>
        <translation>Ajustar ancho de página</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>Ajustar a página</translation>
    </message>
    <message>
        <source>One to one</source>
        <translation>Tamaño real</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <source>Text align</source>
        <translation>Alinear texto</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>Mostrar barra herramientas</translation>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation>Mostrar barra herramientas</translation>
    </message>
    <message>
        <source>InsertTextItem</source>
        <translation>Insertar objeto de texto</translation>
    </message>
    <message>
        <source>Add new TextItem</source>
        <translation>Agregar nuevo objeto de texto</translation>
    </message>
    <message>
        <source>Selection Mode</source>
        <translation>Modo de selección</translation>
    </message>
    <message>
        <source>Delete Item</source>
        <translation>Eliminar objeto</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Supr</translation>
    </message>
    <message>
        <source>MainToolBar</source>
        <translation>BarraHerramientasPrincipal</translation>
    </message>
    <message>
        <source>EditModeTools</source>
        <translation>HerramientasModoEdición</translation>
    </message>
    <message>
        <source>Printing</source>
        <translation>Imprimiendo</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Atención</translation>
    </message>
    <message>
        <source>The printing is in process</source>
        <translation>La impresión esta en proceso</translation>
    </message>
</context>
<context>
    <name>LimeReport::ProxyHolder</name>
    <message>
        <source>Datasource has been invalidated</source>
        <translation>Fuente de datos ha sido invalidada</translation>
    </message>
</context>
<context>
    <name>LimeReport::QObjectPropertyModel</name>
    <message>
        <source>leftMargin</source>
        <translation>Margen izquierdo</translation>
    </message>
    <message>
        <source>rightMargin</source>
        <translation>Margen derecho</translation>
    </message>
    <message>
        <source>topMargin</source>
        <translation>Margen superior</translation>
    </message>
    <message>
        <source>bottomMargin</source>
        <translation>Margen inferior</translation>
    </message>
    <message>
        <source>objectName</source>
        <translation>Nombre del objeto</translation>
    </message>
    <message>
        <source>borders</source>
        <translation>Bordes</translation>
    </message>
    <message>
        <source>geometry</source>
        <translation>geometria</translation>
    </message>
    <message>
        <source>itemAlign</source>
        <translation>Alineación del objeto</translation>
    </message>
    <message>
        <source>pageOrientation</source>
        <translation>Orientación de la página</translation>
    </message>
    <message>
        <source>pageSize</source>
        <translation>Tamaño de página</translation>
    </message>
    <message>
        <source>TopLine</source>
        <translation>Linea superior</translation>
    </message>
    <message>
        <source>BottomLine</source>
        <translation>Linea inferior</translation>
    </message>
    <message>
        <source>LeftLine</source>
        <translation>Linea izquierda</translation>
    </message>
    <message>
        <source>RightLine</source>
        <translation>Linea derecha</translation>
    </message>
    <message>
        <source>reprintOnEachPage</source>
        <translation>Re-imprimir en cada página</translation>
    </message>
    <message>
        <source>borderLineSize</source>
        <translation>Grosor de borde</translation>
    </message>
    <message>
        <source>autoHeight</source>
        <translation>Alto automático</translation>
    </message>
    <message>
        <source>backgroundColor</source>
        <translation>Color de fondo</translation>
    </message>
    <message>
        <source>columnCount</source>
        <translation>Cantidad de columnas</translation>
    </message>
    <message>
        <source>columnsFillDirection</source>
        <translation>Dirección llenado columnas</translation>
    </message>
    <message>
        <source>datasource</source>
        <translation>fuente de datos</translation>
    </message>
    <message>
        <source>keepBottomSpace</source>
        <translation>Conservar espacio inferior</translation>
    </message>
    <message>
        <source>keepFooterTogether</source>
        <translation>Mantener pie junto</translation>
    </message>
    <message>
        <source>keepSubdetailTogether</source>
        <translation>Mantener sub-detalle junto</translation>
    </message>
    <message>
        <source>printIfEmpty</source>
        <translation>imprimir si está vacío</translation>
    </message>
    <message>
        <source>sliceLastRow</source>
        <translation>cortar la última fila</translation>
    </message>
    <message>
        <source>splittable</source>
        <translation>Separable</translation>
    </message>
    <message>
        <source>alignment</source>
        <translation>Alineación</translation>
    </message>
    <message>
        <source>angle</source>
        <translation>Angulo</translation>
    </message>
    <message>
        <source>autoWidth</source>
        <translation>Ancho automático</translation>
    </message>
    <message>
        <source>backgroundMode</source>
        <translation>Modo de fondo</translation>
    </message>
    <message>
        <source>backgroundOpacity</source>
        <translation>Opacidad de fondo</translation>
    </message>
    <message>
        <source>content</source>
        <translation>contenido</translation>
    </message>
    <message>
        <source>font</source>
        <translation>fuente</translation>
    </message>
    <message>
        <source>fontColor</source>
        <translation>Color de fuente</translation>
    </message>
    <message>
        <source>foregroundOpacity</source>
        <translation>opacidad de primer plano</translation>
    </message>
    <message>
        <source>itemLocation</source>
        <translation>Ubicación del objeto</translation>
    </message>
    <message>
        <source>margin</source>
        <translation>margen</translation>
    </message>
    <message>
        <source>stretchToMaxHeight</source>
        <translation>estirar a la altura máxima</translation>
    </message>
    <message>
        <source>trimValue</source>
        <translation>Recortar Valor</translation>
    </message>
    <message>
        <source>lineWidth</source>
        <translation>Ancho de linea</translation>
    </message>
    <message>
        <source>opacity</source>
        <translation>opacidad</translation>
    </message>
    <message>
        <source>penStyle</source>
        <translation>estilo de pluma</translation>
    </message>
    <message>
        <source>shape</source>
        <translation>forma</translation>
    </message>
    <message>
        <source>shapeBrush</source>
        <translation>forma del pincel</translation>
    </message>
    <message>
        <source>shapeBrushColor</source>
        <translation>forma del pincel color</translation>
    </message>
    <message>
        <source>Property Name</source>
        <translation>Propiedad</translation>
    </message>
    <message>
        <source>Property value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <source>gridStep</source>
        <translation>Distancia en rejilla</translation>
    </message>
    <message>
        <source>fullPage</source>
        <translation>Página completa</translation>
    </message>
    <message>
        <source>oldPrintMode</source>
        <translation>Modo de impresión viejo</translation>
    </message>
    <message>
        <source>borderColor</source>
        <translation>Color de borde</translation>
    </message>
    <message>
        <source>resetPageNumber</source>
        <translation>Restablecer número de página</translation>
    </message>
    <message>
        <source>alternateBackgroundColor</source>
        <translation>Color de fondo alternativo</translation>
    </message>
    <message>
        <source>backgroundBrushStyle</source>
        <translation>Estilo de bocha de fondo</translation>
    </message>
    <message>
        <source>startFromNewPage</source>
        <translation>Empezar desde nueva página</translation>
    </message>
    <message>
        <source>startNewPage</source>
        <translation>empezar nueva página</translation>
    </message>
    <message>
        <source>adaptFontToSize</source>
        <translation>adaptar fuente al tamaño</translation>
    </message>
    <message>
        <source>allowHTML</source>
        <translation>Permitir HTML</translation>
    </message>
    <message>
        <source>allowHTMLInFields</source>
        <translation>permitir HTML en campos</translation>
    </message>
    <message>
        <source>followTo</source>
        <translation>Permitir hasta</translation>
    </message>
    <message>
        <source>format</source>
        <translation>formato</translation>
    </message>
    <message>
        <source>lineSpacing</source>
        <translation>Espaciado entre líneas</translation>
    </message>
    <message>
        <source>textIndent</source>
        <translation>sangría de texto</translation>
    </message>
    <message>
        <source>textLayoutDirection</source>
        <translation>Dirección del diseño del texto</translation>
    </message>
    <message>
        <source>underlineLineSize</source>
        <translation>grosor del subrayado</translation>
    </message>
    <message>
        <source>underlines</source>
        <translation>subrayar</translation>
    </message>
    <message>
        <source>valueType</source>
        <translation>Tipo de valor</translation>
    </message>
    <message>
        <source>securityLevel</source>
        <translation>nivel seguridad</translation>
    </message>
    <message>
        <source>testValue</source>
        <translation>valor de prueba</translation>
    </message>
    <message>
        <source>whitespace</source>
        <translation>espacio en blanco</translation>
    </message>
    <message>
        <source>resourcePath</source>
        <translation>ruta de recursos</translation>
    </message>
    <message>
        <source>scale</source>
        <translation>escala</translation>
    </message>
    <message>
        <source>cornerRadius</source>
        <translation>radio de esquina</translation>
    </message>
    <message>
        <source>shapeColor</source>
        <translation>color de la forma</translation>
    </message>
    <message>
        <source>layoutType</source>
        <translation>tipo de diseño</translation>
    </message>
    <message>
        <source>barcodeType</source>
        <translation>tipo código barrras</translation>
    </message>
    <message>
        <source>barcodeWidth</source>
        <translation>ancho código barras</translation>
    </message>
    <message>
        <source>foregroundColor</source>
        <translation>color de primer plano</translation>
    </message>
    <message>
        <source>inputMode</source>
        <translation>modo de entrada</translation>
    </message>
    <message>
        <source>pdf417CodeWords</source>
        <translation>palabras del código pdf417</translation>
    </message>
    <message>
        <source>autoSize</source>
        <translation>tamaño automático</translation>
    </message>
    <message>
        <source>center</source>
        <translation>centrado</translation>
    </message>
    <message>
        <source>field</source>
        <translation>campo</translation>
    </message>
    <message>
        <source>image</source>
        <translation>imagen</translation>
    </message>
    <message>
        <source>keepAspectRatio</source>
        <translation>mantener la relación de aspecto</translation>
    </message>
    <message>
        <source>columnsCount</source>
        <translation>recuento de columnas</translation>
    </message>
    <message>
        <source>useAlternateBackgroundColor</source>
        <translation>usar color de fondo alternativo</translation>
    </message>
    <message>
        <source>printBeforePageHeader</source>
        <translation>imprimir antes del encabezado de página</translation>
    </message>
    <message>
        <source>maxScalePercent</source>
        <translation>porcentaje máximo de escala</translation>
    </message>
    <message>
        <source>printOnFirstPage</source>
        <translation>Imprimir en la primera página</translation>
    </message>
    <message>
        <source>printOnLastPage</source>
        <translation>Imprimir en la última página</translation>
    </message>
    <message>
        <source>printAlways</source>
        <translation>imprimir siempre</translation>
    </message>
    <message>
        <source>repeatOnEachRow</source>
        <translation>repetir en cada fila</translation>
    </message>
    <message>
        <source>condition</source>
        <translation>condición</translation>
    </message>
    <message>
        <source>groupFieldName</source>
        <translation>nombre del grupo de campos</translation>
    </message>
    <message>
        <source>keepGroupTogether</source>
        <translation>mantener grupo junto</translation>
    </message>
    <message>
        <source>endlessHeight</source>
        <translation>altura sin fin</translation>
    </message>
    <message>
        <source>extendedHeight</source>
        <translation>alto extendido</translation>
    </message>
    <message>
        <source>isExtendedInDesignMode</source>
        <translation>es el modo de diseño extendido</translation>
    </message>
    <message>
        <source>pageIsTOC</source>
        <translation>la página es TOC</translation>
    </message>
    <message>
        <source>setPageSizeToPrinter</source>
        <translation>ajsutar tamaño de página a la impresora</translation>
    </message>
    <message>
        <source>fillInSecondPass</source>
        <translation>completar segundo paso</translation>
    </message>
    <message>
        <source>chartTitle</source>
        <translation>Titulo del gráfico</translation>
    </message>
    <message>
        <source>chartType</source>
        <translation>tipo gráfico</translation>
    </message>
    <message>
        <source>drawLegendBorder</source>
        <translation>dibujar borde de leyenda</translation>
    </message>
    <message>
        <source>labelsField</source>
        <translation>campo de etiquetas</translation>
    </message>
    <message>
        <source>legendAlign</source>
        <translation>Alinear leyenda</translation>
    </message>
    <message>
        <source>series</source>
        <translation>series</translation>
    </message>
    <message>
        <source>titleAlign</source>
        <translation>alinear titulo</translation>
    </message>
    <message>
        <source>watermark</source>
        <translation>marca de agua</translation>
    </message>
    <message>
        <source>keepTopSpace</source>
        <translation>conservar espacio superior</translation>
    </message>
    <message>
        <source>printable</source>
        <translation>imprimible</translation>
    </message>
    <message>
        <source>variable</source>
        <translation></translation>
    </message>
    <message>
        <source>replaceCRwithBR</source>
        <translation>reemplazar CR con BR</translation>
    </message>
    <message>
        <source>hideIfEmpty</source>
        <translation>ocultar si está vacío</translation>
    </message>
    <message>
        <source>hideEmptyItems</source>
        <translation>ocultar objetos vacíos</translation>
    </message>
    <message>
        <source>useExternalPainter</source>
        <translation>utilizar pintor externo</translation>
    </message>
    <message>
        <source>layoutSpacing</source>
        <translation>espaciado de diseño</translation>
    </message>
    <message>
        <source>printerName</source>
        <translation>nombre impresora</translation>
    </message>
    <message>
        <source>fontLetterSpacing</source>
        <translation>espaciado entre letra y fuente</translation>
    </message>
    <message>
        <source>hideText</source>
        <translation>Ocultar texto</translation>
    </message>
    <message>
        <source>option3</source>
        <translation>Opción3</translation>
    </message>
    <message>
        <source>units</source>
        <translation>unidades</translation>
    </message>
    <message>
        <source>geometryLocked</source>
        <translation>geometriaAsegurada</translation>
    </message>
    <message>
        <source>printBehavior</source>
        <translation>comportamientoImpresión</translation>
    </message>
    <message>
        <source>shiftItems</source>
        <translation>InvertirObjetos</translation>
    </message>
    <message>
        <source>showLegend</source>
        <translation>mostrarLeyenda</translation>
    </message>
    <message>
        <source>removeGap</source>
        <translation>eliminarBrecha</translation>
    </message>
</context>
<context>
    <name>LimeReport::RectPropItem</name>
    <message>
        <source>width</source>
        <translation>ancho</translation>
    </message>
    <message>
        <source>height</source>
        <translation>alto</translation>
    </message>
</context>
<context>
    <name>LimeReport::RectUnitPropItem</name>
    <message>
        <source>width</source>
        <translation>ancho</translation>
    </message>
    <message>
        <source>height</source>
        <translation>alto</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportDesignWidget</name>
    <message>
        <source>Report file name</source>
        <translation>Nombre de archivo del reporte</translation>
    </message>
    <message>
        <source>Script</source>
        <translation></translation>
    </message>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>Wrong file format</source>
        <translation>Formato de archivo incorrecto</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportDesignWindow</name>
    <message>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <source>New Report</source>
        <translation>Nuevo Reporte</translation>
    </message>
    <message>
        <source>Edit Mode</source>
        <translation>Modo de edición</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Use grid</source>
        <translation>Usar cuadricula</translation>
    </message>
    <message>
        <source>Use magnet</source>
        <translation>Usar Imán</translation>
    </message>
    <message>
        <source>Text Item</source>
        <translation>Elemento de texto</translation>
    </message>
    <message>
        <source>Save Report</source>
        <translation>Guardar Reporte</translation>
    </message>
    <message>
        <source>Save Report As</source>
        <translation>Guardar reporte como</translation>
    </message>
    <message>
        <source>Load Report</source>
        <translation>Cargar Reporte</translation>
    </message>
    <message>
        <source>Delete item</source>
        <translation>Eliminar elemento</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Acercarse</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Alejarse</translation>
    </message>
    <message>
        <source>Render Report</source>
        <translation>Generar reporte</translation>
    </message>
    <message>
        <source>Edit layouts mode</source>
        <translation>Modo de edición de diseño</translation>
    </message>
    <message>
        <source>Horizontal layout</source>
        <translation>Diseño horizontal</translation>
    </message>
    <message>
        <source>Report Tools</source>
        <translation>Herramientas de reporte</translation>
    </message>
    <message>
        <source>Main Tools</source>
        <translation>Herramientas principales</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <source>Text alignment</source>
        <translation>Alineación del texto</translation>
    </message>
    <message>
        <source>Items alignment</source>
        <translation>Alineación de elementos</translation>
    </message>
    <message>
        <source>Borders</source>
        <translation>Bordes</translation>
    </message>
    <message>
        <source>Report bands</source>
        <translation>Bandas del reporte</translation>
    </message>
    <message>
        <source>Report Header</source>
        <translation>Encabezado del reporte</translation>
    </message>
    <message>
        <source>Report Footer</source>
        <translation>Pie del Reporte</translation>
    </message>
    <message>
        <source>Page Header</source>
        <translation>Encabezado de página</translation>
    </message>
    <message>
        <source>Page Footer</source>
        <translation>Pie de página</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>Datos</translation>
    </message>
    <message>
        <source>Data Header</source>
        <translation>Encabezado de Datos</translation>
    </message>
    <message>
        <source>Data Footer</source>
        <translation>Pie de Datos</translation>
    </message>
    <message>
        <source>SubDetail</source>
        <translation>Sub-Detalle</translation>
    </message>
    <message>
        <source>SubDetailHeader</source>
        <translation>Encabezado de Sub-Detalle</translation>
    </message>
    <message>
        <source>SubDetailFooter</source>
        <translation>Pie de Sub-Detalle</translation>
    </message>
    <message>
        <source>GroupHeader</source>
        <translation>Encabezado de grupo</translation>
    </message>
    <message>
        <source>GroupFooter</source>
        <translation>Pie de Grupo</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>Archivos recientes</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>Inspector de objectos</translation>
    </message>
    <message>
        <source>Report structure</source>
        <translation>Estructura del reporte</translation>
    </message>
    <message>
        <source>Data Browser</source>
        <translation>Navegador de datos</translation>
    </message>
    <message>
        <source>Report file name</source>
        <translation>Nombre de archivo del reporte</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <source>File &quot;%1&quot; not found!</source>
        <translation>¡No se encontró el archivo &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>New Report Page</source>
        <translation>Nueva página para el reporte</translation>
    </message>
    <message>
        <source>Delete Report Page</source>
        <translation>Eliminar página del reporte</translation>
    </message>
    <message>
        <source>Script Browser</source>
        <translation>Navegador de Script</translation>
    </message>
    <message>
        <source>Tear-off Band</source>
        <translation>Banda de corte</translation>
    </message>
    <message>
        <source>Delete dialog</source>
        <translation>Eliminar dialogo</translation>
    </message>
    <message>
        <source>Add new dialog</source>
        <translation>Agregar nuevo dialogo</translation>
    </message>
    <message>
        <source>Widget Box</source>
        <translation>Caja de Widget</translation>
    </message>
    <message>
        <source>Property Editor</source>
        <translation>Editor de propiedades</translation>
    </message>
    <message>
        <source>Action Editor</source>
        <translation>Editor de acción</translation>
    </message>
    <message>
        <source>Resource Editor</source>
        <translation>Editor de recursos</translation>
    </message>
    <message>
        <source>SignalSlot Editor</source>
        <translation>Editor de señales</translation>
    </message>
    <message>
        <source>Dialog Designer Tools</source>
        <translation>Herramientas de diseño de Dialogos</translation>
    </message>
    <message>
        <source>Report has been modified! Do you want save the report?</source>
        <translation>¡El reporte ha sido modificado! ¿Quieres guardar el reporte?</translation>
    </message>
    <message>
        <source>Hide left panel | Alt+L</source>
        <translation>Ocultar panel izquierdo | Alt + L</translation>
    </message>
    <message>
        <source>Hide right panel | Alt+R</source>
        <translation>Ocultar panel derecho | Alt + L</translation>
    </message>
    <message>
        <source>Vertical layout</source>
        <translation>Diseño vertical</translation>
    </message>
    <message>
        <source>Rendered %1 pages</source>
        <translation>%1 páginas renderizadas</translation>
    </message>
    <message>
        <source>Cancel report rendering</source>
        <translation>Cancelar renderizado del reporte</translation>
    </message>
    <message>
        <source>Lock selected items</source>
        <translation>Asegurar objetos seleccionados</translation>
    </message>
    <message>
        <source>Unlock selected items</source>
        <translation>Desbloquear objetos seleccionados</translation>
    </message>
    <message>
        <source>Select one level items</source>
        <translation>Seleccionar elementos de un nivel</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Atención</translation>
    </message>
    <message>
        <source>The rendering is in process</source>
        <translation>La renderización está en proceso</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportEnginePrivate</name>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>Report File Change</source>
        <translation>Repore cambios en archivo</translation>
    </message>
    <message>
        <source>The report file &quot;%1&quot; has changed names or been deleted.

This preview is no longer valid.</source>
        <translation>El archivo del informe &quot;%1&quot; ha cambiado los nombres o se ha eliminado.

Esta vista previa ya no es válida.</translation>
    </message>
    <message>
        <source>Language %1 already exists</source>
        <translation>El idioma %1 ya existe</translation>
    </message>
    <message>
        <source>Designer not found!</source>
        <translation>Diseñador no encontrado!</translation>
    </message>
    <message>
        <source>%1 file name</source>
        <translation>Nombre de archivo %1</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportFooter</name>
    <message>
        <source>Report Footer</source>
        <translation>Pie reporte</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportHeader</name>
    <message>
        <source>Report Header</source>
        <translation>Encabezado reporte</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportRender</name>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>Databand &quot;%1&quot; not found</source>
        <translation>Banda de datos &quot;%1&quot; no encontrada</translation>
    </message>
    <message>
        <source>Wrong using function %1</source>
        <translation>Error al utilizar la función %1</translation>
    </message>
    <message>
        <source>page index out of range</source>
        <translation>índice de página fuera de rango</translation>
    </message>
</context>
<context>
    <name>LimeReport::SQLEditDialog</name>
    <message>
        <source>Connection</source>
        <translation>Conexión</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Atención</translation>
    </message>
    <message>
        <source>Datasource</source>
        <translation>Fuente de datos</translation>
    </message>
    <message>
        <source>Datasource Name</source>
        <translation>Nombre de fuente de datos</translation>
    </message>
    <message>
        <source>Subdetail</source>
        <translation>Sub-detalle</translation>
    </message>
    <message>
        <source>Master datasource</source>
        <translation>Fuente de datos primaria</translation>
    </message>
    <message>
        <source>Subquery mode</source>
        <translation>Modo de sub consulta</translation>
    </message>
    <message>
        <source>Filter mode</source>
        <translation>Modo de filtrado</translation>
    </message>
    <message>
        <source>SQL</source>
        <translation>SQL</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>Hide Preview</source>
        <translation>Ocultar vista previa</translation>
    </message>
    <message>
        <source>Child datasource</source>
        <translation>Fuente de datos hija</translation>
    </message>
    <message>
        <source>Fields map</source>
        <translation>Mapa de campos</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Data preview</source>
        <translation>Vista previa de datos</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>Datasource with name %1 already exist</source>
        <translation>La fuente de datos con el nombre %1 ya existe</translation>
    </message>
    <message>
        <source>Connection is not specified</source>
        <translation>La conexión no está especificada</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Refrescar</translation>
    </message>
    <message>
        <source>defaultConnection</source>
        <translation>Conexión por defecto</translation>
    </message>
    <message>
        <source>Datasource Name is empty!</source>
        <translation>Nombre de la fuente de datos está vacío!</translation>
    </message>
    <message>
        <source>SQL is empty!</source>
        <translation>SQL está vacío!</translation>
    </message>
    <message>
        <source>Datasource with name: &quot;%1&quot; already exists!</source>
        <translation>Fuente de datos con nombre: &quot;%1&quot; ya existe!</translation>
    </message>
    <message>
        <source>CSV</source>
        <translation></translation>
    </message>
    <message>
        <source>Separator</source>
        <translation>Separador</translation>
    </message>
    <message>
        <source>;</source>
        <translation></translation>
    </message>
    <message>
        <source>Use first row as header</source>
        <translation>Usa la primera fila como encabezado</translation>
    </message>
</context>
<context>
    <name>LimeReport::SVGItem</name>
    <message>
        <source>SVG Image</source>
        <translation>Imagen SVG</translation>
    </message>
    <message>
        <source>SVG (*.svg)</source>
        <translation></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>Marca de agua</translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptBrowser</name>
    <message>
        <source>Form</source>
        <translation>De</translation>
    </message>
    <message>
        <source>Functions</source>
        <translation>Funciones</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Dialogs</source>
        <translation>Dialogos</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>NO CATEGORY</source>
        <translation>NO CATEGORIA</translation>
    </message>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>Dialog with name: %1 already exists</source>
        <translation>Diálogo con nombre: %1 ya existe</translation>
    </message>
    <message>
        <source>ui file must cointain QDialog instead QWidget or QMainWindow</source>
        <translation>El archivo ui debe contener QDialog en lugar de QWidget o QMainWindow</translation>
    </message>
    <message>
        <source>wrong file format</source>
        <translation>formato de archivo incorrecto</translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptEditor</name>
    <message>
        <source>Form</source>
        <translation>De</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>Datos</translation>
    </message>
    <message>
        <source>Functions</source>
        <translation>Funciones</translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptEngineContext</name>
    <message>
        <source>Dialog with name: %1 can`t be created</source>
        <translation>Diálogo con nombre: %1 no puede ser creado</translation>
    </message>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptEngineManager</name>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>BandName</source>
        <translation>Nombre de banda</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Precision</source>
        <translation>Precisión</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>CurrencySymbol</source>
        <translation>Símbolo de moneda</translation>
    </message>
    <message>
        <source>Variable %1 not found</source>
        <translation>Variable %1 no encontrada</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>GROUP FUNCTIONS</source>
        <translation>Funciones de grupo</translation>
    </message>
    <message>
        <source>FieldName</source>
        <translation>Nombre campo</translation>
    </message>
    <message>
        <source>Field %1 not found in %2!</source>
        <translation>¡El campo %1 no se encuentra en %2!</translation>
    </message>
    <message>
        <source>SYSTEM</source>
        <translation>SISTEMA</translation>
    </message>
    <message>
        <source>NUMBER</source>
        <translation>NUMEROS</translation>
    </message>
    <message>
        <source>DATE&amp;TIME</source>
        <translation>FECHA Y HORA</translation>
    </message>
    <message>
        <source>GENERAL</source>
        <translation></translation>
    </message>
    <message>
        <source>Datasource</source>
        <translation>Fuente datos</translation>
    </message>
    <message>
        <source>ValueField</source>
        <translation>Valor campo</translation>
    </message>
    <message>
        <source>KeyField</source>
        <translation>Campo clave</translation>
    </message>
    <message>
        <source>KeyFieldValue</source>
        <translation>Valor campo clave</translation>
    </message>
    <message>
        <source>Unique identifier</source>
        <translation>Identificador único</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <source>Indent</source>
        <translation>Sangrar</translation>
    </message>
    <message>
        <source>datasourceName</source>
        <translation>Nombre de fuente de datos</translation>
    </message>
    <message>
        <source>Function manager with name &quot;%1&quot; already exists!</source>
        <translation>¡El administrador de funciones con el nombre &quot;%1&quot; ya existe!</translation>
    </message>
    <message>
        <source>RowIndex</source>
        <translation>Índice de fila</translation>
    </message>
</context>
<context>
    <name>LimeReport::SettingDialog</name>
    <message>
        <source>Designer setting</source>
        <translation>Configuración de diseñador</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation>Fuente predeterminada</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Cuadrícula</translation>
    </message>
    <message>
        <source>Vertical grid step</source>
        <translation>Espaciado de rejilla vertical</translation>
    </message>
    <message>
        <source>Horizontal grid step</source>
        <translation>Espaciado de rejilla horizontal</translation>
    </message>
    <message>
        <source>Suppress absent fields and variables warning</source>
        <translation>Suprimir campos ausentes y variables de advertencia.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Designer settings</source>
        <translation>Configuracion del diseñador</translation>
    </message>
    <message>
        <source>Script editor settings</source>
        <translation>Configuracion del editor de scripts</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <source>Indent size</source>
        <translation>Tamaño de sangría</translation>
    </message>
    <message>
        <source>Report settings</source>
        <translation>Configuración de informes</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Report units</source>
        <translation>Unidades de reporte</translation>
    </message>
</context>
<context>
    <name>LimeReport::SubDetailBand</name>
    <message>
        <source>SubDetail</source>
        <translation>Sub-Detalle</translation>
    </message>
</context>
<context>
    <name>LimeReport::SubDetailHeaderBand</name>
    <message>
        <source>SubDetailHeader</source>
        <translation>Encabezado sub-detalle</translation>
    </message>
</context>
<context>
    <name>LimeReport::SvgEditor</name>
    <message>
        <source>Select image file</source>
        <translation>Seleccionar archivo de imagen</translation>
    </message>
</context>
<context>
    <name>LimeReport::TearOffBand</name>
    <message>
        <source>Tear-off Band</source>
        <translation>Banda de corte</translation>
    </message>
</context>
<context>
    <name>LimeReport::TextAlignmentEditorWidget</name>
    <message>
        <source>Text align left</source>
        <translation>Alinear texto a la izquierda</translation>
    </message>
    <message>
        <source>Text align center</source>
        <translation>Centrar texto</translation>
    </message>
    <message>
        <source>Text align right</source>
        <translation>Alinear texto a la derecha</translation>
    </message>
    <message>
        <source>Text align justify</source>
        <translation>Justificar texto</translation>
    </message>
    <message>
        <source>Text align top</source>
        <translation>Alinear texto arriba</translation>
    </message>
    <message>
        <source>Text align bottom</source>
        <translation>Alinear texto abajo</translation>
    </message>
</context>
<context>
    <name>LimeReport::TextItem</name>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Auto height</source>
        <translation>Altura automática</translation>
    </message>
    <message>
        <source>Allow HTML</source>
        <translation>Permitir HTML</translation>
    </message>
    <message>
        <source>Allow HTML in fields</source>
        <translation>Permitir HTML en los campos</translation>
    </message>
    <message>
        <source>Stretch to max height</source>
        <translation>Estirar a la altura máxima</translation>
    </message>
    <message>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <source>TextItem &quot; %1 &quot; already has folower &quot; %2 &quot; </source>
        <translation>Objeto de texto &quot;%1&quot; ya tiene el siguiente &quot;%2&quot;</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <source>TextItem &quot; %1 &quot; not found!</source>
        <translation>Objeto de texto &quot;%1&quot; no encontrado!</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>Marca de agua</translation>
    </message>
    <message>
        <source>Hide if empty</source>
        <translation>Ocultar si está vacío</translation>
    </message>
</context>
<context>
    <name>LimeReport::TextItemEditor</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Text Item Editor</source>
        <translation>Editor de objeto de texto</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Ctrl+Return</source>
        <translation>Ctrl+Intro</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>LimeReport::TranslationEditor</name>
    <message>
        <source>Form</source>
        <translation>De</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Strings</source>
        <translation>Cadenas</translation>
    </message>
    <message>
        <source>Source Text</source>
        <translation>Texto fuente</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>Revisada</translation>
    </message>
    <message>
        <source>Report Item</source>
        <translation>Objeto del reporte</translation>
    </message>
    <message>
        <source>Property</source>
        <translation>Propiedad</translation>
    </message>
    <message>
        <source>Source text</source>
        <translation>Texto fuente</translation>
    </message>
</context>
<context>
    <name>LimeReport::VariablesHolder</name>
    <message>
        <source>variable with name </source>
        <translation>variable con el nombre </translation>
    </message>
    <message>
        <source> already exists!</source>
        <translation> ¡ya existe!</translation>
    </message>
    <message>
        <source> does not exists!</source>
        <translation> no existe!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Data</source>
        <translation>Datos</translation>
    </message>
    <message>
        <source>DataHeader</source>
        <translation>Encabezado datos</translation>
    </message>
    <message>
        <source>DataFooter</source>
        <translation>Pie datos</translation>
    </message>
    <message>
        <source>GroupHeader</source>
        <translation>Encabezado grupo</translation>
    </message>
    <message>
        <source>GroupFooter</source>
        <translation>Pie grupo</translation>
    </message>
    <message>
        <source>Page Footer</source>
        <translation>Pie de página</translation>
    </message>
    <message>
        <source>Page Header</source>
        <translation>Encabezado de página</translation>
    </message>
    <message>
        <source>Report Footer</source>
        <translation>Pie de reporte</translation>
    </message>
    <message>
        <source>Report Header</source>
        <translation>Cabezado de reporte</translation>
    </message>
    <message>
        <source>SubDetail</source>
        <translation>Sub-Detalle</translation>
    </message>
    <message>
        <source>SubDetailHeader</source>
        <translation>Encabezado sub-detalle</translation>
    </message>
    <message>
        <source>SubDetailFooter</source>
        <translation>Pie sub-detalle</translation>
    </message>
    <message>
        <source>alignment</source>
        <translation>alineación</translation>
    </message>
    <message>
        <source>Barcode Item</source>
        <translation>Objeto código barras</translation>
    </message>
    <message>
        <source>HLayout</source>
        <translation>diseño horizontal</translation>
    </message>
    <message>
        <source>Image Item</source>
        <translation>Objeto Imagen</translation>
    </message>
    <message>
        <source>Shape Item</source>
        <translation>Objeto de forma</translation>
    </message>
    <message>
        <source>itemLocation</source>
        <translation>Ubicación del objeto</translation>
    </message>
    <message>
        <source>Text Item</source>
        <translation>Objeto de texto</translation>
    </message>
    <message>
        <source>Invalid connection! %1</source>
        <translation>¡Conexión inválida! %1</translation>
    </message>
    <message>
        <source>Master datasouce &quot;%1&quot; not found!</source>
        <translation>No se encontró la fuente de datos maestra &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Child</source>
        <translation>Hijo</translation>
    </message>
    <message>
        <source> and child </source>
        <translation> y hijo</translation>
    </message>
    <message>
        <source>datasouce &quot;%1&quot; not found!</source>
        <translation>fuente de datos &quot;%1&quot; no encontrada!</translation>
    </message>
    <message>
        <source>Attention!</source>
        <translation>¡Atención!</translation>
    </message>
    <message>
        <source>Selected elements have different parent containers</source>
        <translation>Los elementos seleccionados tienen diferentes contenedores padre</translation>
    </message>
    <message>
        <source>Function %1 not found or have wrong arguments</source>
        <translation>La función %1 no se encuentra o tiene argumentos incorrectos</translation>
    </message>
    <message>
        <source>bool</source>
        <translation></translation>
    </message>
    <message>
        <source>QColor</source>
        <translation></translation>
    </message>
    <message>
        <source>content</source>
        <translation>contenido</translation>
    </message>
    <message>
        <source>datasource</source>
        <translation>fuente datos</translation>
    </message>
    <message>
        <source>field</source>
        <translation>campo</translation>
    </message>
    <message>
        <source>enum</source>
        <translation>enumerar</translation>
    </message>
    <message>
        <source>flags</source>
        <translation>opciones</translation>
    </message>
    <message>
        <source>QFont</source>
        <translation></translation>
    </message>
    <message>
        <source>QImage</source>
        <translation></translation>
    </message>
    <message>
        <source>int</source>
        <translation></translation>
    </message>
    <message>
        <source>qreal</source>
        <translation></translation>
    </message>
    <message>
        <source>QRect</source>
        <translation></translation>
    </message>
    <message>
        <source>QRectF</source>
        <translation></translation>
    </message>
    <message>
        <source>geometry</source>
        <translation>geometria</translation>
    </message>
    <message>
        <source>mm</source>
        <translation></translation>
    </message>
    <message>
        <source>QString</source>
        <translation></translation>
    </message>
    <message>
        <source>File %1 not opened</source>
        <translation>Archivo %1 no abierto</translation>
    </message>
    <message>
        <source>Content string is empty</source>
        <translation>La cadena de contenido está vacía</translation>
    </message>
    <message>
        <source>Content is empty</source>
        <translation>El contenido esta vacio</translation>
    </message>
    <message>
        <source>Wrong file format</source>
        <translation>Formato de archivo incorrecto</translation>
    </message>
    <message>
        <source>Tear-off Band</source>
        <translation>Banda de corte</translation>
    </message>
    <message>
        <source>Chart Item</source>
        <translation>Objeto gráfico</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Primero</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Segundo</translation>
    </message>
    <message>
        <source>Thrid</source>
        <translation>Tercero</translation>
    </message>
    <message>
        <source>Master datasource &quot;%1&quot; not found!</source>
        <translation>¡No se encontró la fuente de datos maestra &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Object with name %1 already exists!</source>
        <translation>¡El objeto con nombre %1 ya existe!</translation>
    </message>
    <message>
        <source>Datasource manager not found</source>
        <translation>Administrador de fuente de datos no encontrado</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>Exportar a PDF</translation>
    </message>
    <message>
        <source>VLayout</source>
        <translation>Diseño vertical</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Por defecto</translation>
    </message>
    <message>
        <source>SVG Item</source>
        <translation>Objeto SVG</translation>
    </message>
    <message>
        <source>image</source>
        <translation>imagen</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Oscuro</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Claro</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Milimetros</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Pulgadas</translation>
    </message>
    <message>
        <source>margin</source>
        <translation>margen</translation>
    </message>
    <message>
        <source>&apos;&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>series</source>
        <translation>series</translation>
    </message>
    <message>
        <source>Series</source>
        <translation>Series</translation>
    </message>
</context>
</TS>
